# ACKO Umbrella DS — Semantics

> **Layer 5 of 6.** The role/theme layer. Every color on every canvas layer must trace back here. Modes: **Light | Dark**. Aliases Brand (for brand-tinted roles) or Primitives (for neutrals).

**Source of truth:** `@acko/tokens@4.0.3` → `tokens.css` under `[data-theme="light"]` (also `:root`) / `[data-theme="dark"]`.

---

## Key rule

**One alias per token, no raw values.** A semantic token holds either a Brand alias or a Primitives alias — never an RGB literal. Components alias Semantics; they never skip to Brand or Primitives directly.

**Four families only:** `surface/*`, `text/*`, `border/*`, `icon/*`. The v1 `fill/*`, `status/*`, `accent/*`, `disabled/*` and flat `surface/fill/*` groups are **removed** in 4.0.3 — their roles now live inside the four families (see the migration table at the end). Legacy `--color*` tokens are also gone.

```
Figma path               CSS var                   Example alias chain
text/primary         →   --textPrimary         →   --solidGrey750 (light)
surface/action/default → --surfaceActionDefault →  --brandActionDefault → --brandPrimary950 → --solidPurple950
surface/page/primary →   --surfacePagePrimary  →   --solidGrey50 (light)
```

Tokens marked **†** are brand-aware: they alias `--brand*` and re-resolve under `[data-brand="ackodrive"]` / `[data-brand="ackoclinic"]`.

---

## text/

Use for all `TEXT_FILL` properties.

| Figma | CSS var | Light | Dark | When to use |
|---|---|---|---|---|
| `text/primary` | `--textPrimary` | `solidGrey750` | `solidGrey100` | Default body copy, headings, input values |
| `text/secondary` | `--textSecondary` | `solidGrey500` | `solidGrey250` | Supporting text, labels, captions |
| `text/tertiary` | `--textTertiary` | `solidGrey300` | `solidGrey350` | Timestamps, helper text, placeholders |
| `text/muted` | `--textMuted` | `solidGrey450` | `solidGrey450` | De-emphasised labels |
| `text/disabled` | `--textDisabled` | `solidGrey250` | `solidGrey500` | All text inside a disabled state |
| `text/disabledStrong` | `--textDisabledStrong` | `solidGrey300` | `solidGrey450` | Disabled text that must stay legible |
| `text/inverse` | `--textInverse` | `solidGrey100` | `solidGrey750` | Text on dark/filled surfaces |
| `text/brand/default` † | `--textBrandDefault` | `brandPrimary600` | `brandPrimary200` | Brand-coloured text (active labels) |
| `text/brand/strong` † | `--textBrandStrong` | `brandPrimary900` | `brandPrimary600` | Stronger brand emphasis |
| `text/brand/onBrand` † | `--textBrandOnBrand` | `brandPrimaryWhite` | `brandPrimaryWhite` | Text placed directly on a brand-fill surface |
| `text/action/label` † | `--textActionLabel` | `brandActionOnAction` | `brandActionOnActionInverse` | Label on a primary action fill (primary button) |
| `text/action/labelInverse` † | `--textActionLabelInverse` | `brandLabelDefault` | `brandLabelDefaultInverse` | Brand label on light fills (secondary / ghost button) |
| `text/link/default` | `--textLinkDefault` | `solidBlue600` | `solidBlue400` | Hyperlinks (`--textLinkHover`, `--textLinkPressed` for states) |
| `text/static/light` | `--textStaticLight` | `solidGreyWhite` | `solidGreyWhite` | Always light regardless of theme |
| `text/static/dark` | `--textStaticDark` | `solidGrey800` | `solidGrey800` | Always dark regardless of theme |
| `text/danger/label` | `--textDangerLabel` | `solidRed700` | `solidRed300` | Destructive action label |

Also available: `--textBrandLight` †, `--textStaticBrand` †, `--textStaticDisabled`, `--textStaticLightDisabled`, `--textDangerOnDanger`, and the `*Fixed` variants (`--textLinkFixed*`, `--textStaticFixed*`, `--textDangerFixedOnStatic`) that keep one value in both themes.

**Typography `color` prop — intended role:** `primary` → `--textPrimary` · `secondary` → `--textSecondary` · `invert` → `--textInverse` · `brand` → `--textBrandDefault` · `error` → `--textStatusError` · `success` → `--textStatusSuccess` · `static` → `--textStaticLight`. (In 4.0.3, `invert` / `brand` / `error` / `success` don't render — see `typography.md`.)

---

## surface/

Use for `FRAME_FILL` and `SHAPE_FILL` on pages, sheets and containers.

| Figma | CSS var | Light | Dark | When to use |
|---|---|---|---|---|
| `surface/page/primary` | `--surfacePagePrimary` | `solidGrey50` | `solidGrey750` | Page / screen background — Primary page surface (flat) |
| `surface/page/secondary` | `--surfacePageSecondary` | `solidGrey150` | `solidGrey800` | Secondary (recessed) page surface |
| `surface/page/muted` | `--surfacePageMuted` | `alphaGreyA50` | `alphaGreyA700` | Muted background (sidebars, wells) |
| `surface/page/inverse` | `--surfacePageInverse` | `solidGrey650` | `solidGrey150` | Dark surface in light mode (and vice-versa) |
| `surface/page/brand` † | `--surfacePageBrand` | `brandSelectionActive` | `brandSurfaceSubtleHoverInverse` | Full-bleed brand-coloured page section |
| `surface/overlay/default` | `--surfaceOverlayDefault` | `alphaGreyA400` | `alphaGreyA500` | Modal scrim / backdrop (`…Hover`, `…Active` for translucent controls) |
| `surface/static/black` | `--surfaceStaticBlack` | `solidGrey700` | `solidGrey700` | Always black surface |
| `surface/static/white` | `--surfaceStaticWhite` | `solidGreyWhite` | `solidGrey150` | Light surface that softens in dark mode |
| `surface/static/whiteFixed` | `--surfaceStaticWhiteFixed` | `solidGreyWhite` | `solidGreyWhite` | Always pure white |
| `surface/brand/strong` † | `--surfaceBrandStrong` | `brandPrimary600` | `brandPrimary800` | Brand-coloured surface |
| `surface/brand/light` † | `--surfaceBrandLight` | `brandPrimary200` | `brandAlphaSubtle` | Lighter brand-tinted surface |
| `surface/brand/subtle` † | `--surfaceBrandSubtle` | `brandAlphaSubtle` | `brandAlphaLight` | Faint brand wash (secondary button bg) — `…Hover` / `…Active` for states |

`surface/brandRamp/*` † (`--surfaceBrandRamp{Deep,Dark,Strong,Default,Subtle,Soft,Light,Lightest}`) is an 8-step brand ramp used by selector chips, dropdown selection and wizards; `--surfaceBrandGradientFrom/To` † feed brand gradients.

---

## surface/card · surface/input · surface/danger — interactive fills

| Figma | CSS var | Light | Dark | When to use |
|---|---|---|---|---|
| `surface/card/default` | `--surfaceCardDefault` | `solidGreyWhite` | `solidGrey700` | Default card / elevated fill (behind `--cardFillDefault`) |
| `surface/card/hover` | `--surfaceCardHover` | `alphaGreyA50` | `solidGrey100` | Hover state |
| `surface/card/active` | `--surfaceCardActive` | `solidGrey200` | `solidGrey550` | Pressed/active state |
| `surface/card/muted` | `--surfaceCardMuted` | `alphaGreyA50` | `alphaWhiteA50` | Muted container (`<Card variant="muted">`) |
| `surface/card/subtle` | `--surfaceCardSubtle` | `solidGrey150` | `solidGrey700` | Very light tint / demoted containers, toggle track |
| `surface/card/ghost` | `--surfaceCardGhost` | `alphaGreyA00` | `alphaGreyA00` | Ghost / transparent interactive element |
| `surface/card/disabled` | `--surfaceCardDisabled` | `solidGrey150` | `solidGrey650` | Disabled container fill |
| `surface/card/inverse` | `--surfaceCardInverse` | `solidGrey700` | `solidGrey150` | Inverted interactive fill |
| `surface/input/default` | `--surfaceInputDefault` | `solidGreyWhite` | `solidGrey800` | Text input background |
| `surface/input/focus` † | `--surfaceInputFocus` | `brandAlphaSubtle` | `brandAlphaSubtle` | Text input focused background |
| `surface/danger/default` | `--surfaceDangerDefault` | `alphaRedA100` | `alphaRedA200` | Error / destructive fill (`…Hover`, `…Active`) |
| `surface/danger/strong` | `--surfaceDangerStrong` | `solidRed600` | `solidRed600` | High-emphasis destructive fill (`…StrongHover`, `…StrongActive`) |
| `surface/static/whiteHover` | `--surfaceStaticWhiteHover` | `solidGrey150` | `solidGrey150` | Hover on an always-white fill (`--surfaceStaticWhiteActive` for pressed) |

---

## surface/action · surface/control — brand-interactive fills

Use for buttons (action) and selection controls — checkboxes, radios, switches, toggles (control).

| Figma | CSS var | Light | Dark | When to use |
|---|---|---|---|---|
| `surface/action/default` † | `--surfaceActionDefault` | `brandActionDefault` | `brandActionDefaultInverse` | Primary button fill |
| `surface/action/hover` † | `--surfaceActionHover` | `brandActionHover` | `brandActionHoverInverse` | Primary button hover |
| `surface/action/active` † | `--surfaceActionActive` | `brandActionActive` | `brandActionActiveInverse` | Primary button pressed |
| `surface/control/selected` † | `--surfaceControlSelected` | `brandSelectionDefault` | `brandSelectionDefaultInverse` | Checked checkbox / radio / switch |
| `surface/control/selectedHover` † | `--surfaceControlSelectedHover` | `brandSelectionHover` | `brandSelectionHoverInverse` | Selected control hover |
| `surface/control/selectedActive` † | `--surfaceControlSelectedActive` | `brandSelectionActive` | `brandSelectionHoverInverse` | Selected control pressed |
| `surface/control/disabled` | `--surfaceControlDisabled` | `solidGrey150` | `solidGrey650` | Disabled control / primary button fill |
| `surface/control/disabledStrong` | `--surfaceControlDisabledStrong` | `solidGrey300` | `alphaWhiteA200` | Disabled checked control |

`--surfaceActionInverseDefault|Hover|Active` † keep the inverse (lighter) action fill in both themes.

**Brand layer (Layer 4)** — semantic tokens alias these; components should not. ACKO values shown; `[data-brand="ackodrive"]` re-points them to Green (secondary Blue), `[data-brand="ackoclinic"]` to Pink (secondary Sage).

| Group | CSS vars | ACKO value |
|---|---|---|
| Primary scale | `--brandPrimary{50,100,150,200,300,400,500,600,700,800,850,900,950}`, `--brandPrimaryWhite` | `solidPurple{n}`, `solidGreyWhite` |
| Secondary scale | `--brandSecondary{100…900}` | `solidGreyWhite` → `solidPurple900` |
| Action (buttons) | `--brandActionDefault` / `Hover` / `Active` / `OnAction` | `brandPrimary950` / `900` / `850` / `brandPrimaryWhite` |
| Action, inverse | `--brandActionDefaultInverse` / `HoverInverse` / `ActiveInverse` / `OnActionInverse` | `brandPrimary700` / `800` / `850` / `brandPrimaryWhite` |
| Selection controls | `--brandSelectionDefault` / `Hover` / `Active` / `OnSelection` | `brandPrimary600` / `700` / `800` / `brandPrimaryWhite` |
| Selection, inverse | `--brandSelectionDefaultInverse` / `HoverInverse` | `brandPrimary400` / `300` |
| Tinted surfaces | `--brandSurfaceSubtle` / `SubtleHover` / `SubtleInverse` / `SubtleHoverInverse` | `brandPrimary100` / `150` / `950` / `900` |
| Brand text | `--brandLabelDefault` / `Hover` / `DefaultInverse` / `HoverInverse` | `brandPrimary700` / `500` / `200` / `300` |
| Alpha tints | `--brandAlphaNone` / `Subtle` / `Wash` / `Light` / `Medium` / `Bold` / `Strong` | `alphaPurpleA00` / `A100` / `A150` / `A200` / `A300` / `A400` / `A600` |
| Shape | `--brandRadiusCard` / `--brandRadiusButton` | `--radius5xl` (24px) / `--radiusFull` |
| Font | `--brandTypefaceFont` | `"Euclid Circular B"` (`--typefaceFamily` is a legacy alias of it) |

Note the split: **primary buttons use the deep Action ramp (Purple 950)**, while **selection controls use the Selection ramp (Purple 600)**.

---

## border/

Use for `STROKE_COLOR`.

| Figma | CSS var | Light | Dark | When to use |
|---|---|---|---|---|
| `border/default/soft` | `--borderDefaultSoft` | `alphaGreyA50` | `alphaWhiteA50` | Dividers, hairline separators, card borders |
| `border/default/subtle` | `--borderDefaultSubtle` | `solidGrey200` | `solidGrey650` | Very light borders, explicit divider lines |
| `border/default/medium` | `--borderDefaultMedium` | `alphaGreyA100` | `alphaWhiteA100` | Default component border (checkbox, radio, dropdown panel) |
| `border/default/strong` | `--borderDefaultStrong` | `alphaGreyA150` | `alphaWhiteA150` | Emphasis / hover border |
| `border/default/selected` | `--borderDefaultSelected` | `alphaGreyA300` | `alphaWhiteA200` | Selected/active border |
| `border/default/disabled` | `--borderDefaultDisabled` | `alphaGreyA200` | `solidGrey600` | Disabled border |
| `border/control/default` | `--borderControlDefault` | `solidGrey300` | `solidGrey450` | Form control default border |
| `border/brand/subtle` † | `--borderBrandSubtle` | `brandPrimary500` | `brandPrimary400` | Brand-coloured border |
| `border/brand/control` † | `--borderBrandControl` | `brandSelectionDefault` | `brandSelectionDefaultInverse` | Border of a selected control |
| `border/brand/wash` † | `--borderBrandWash` | `brandAlphaMedium` | `brandAlphaBold` | Soft brand border (secondary button) |
| `border/focus` † | `--borderFocus` | `brandAlphaMedium` | `brandAlphaMedium` | Keyboard focus ring |
| `border/status/error` | `--borderStatusError` | `alphaRedA500` | `alphaRedA500` | Error state border |

Also available: `--borderDefaultHighlight`, `--borderDefaultTranslucent`, `--borderBrandDefault` †, `--borderBrandSelection` †, `--borderStatic{Light,Subtle,Black,WhiteDisabled}`, and the `*Fixed` variants (`--borderBrandFixedTrack` †, `--borderDangerFixed*`, `--borderStaticFixed*`).

`--borderControl` is a **width** token (`0.125rem`), not a colour — use `--borderControlDefault` for the control border colour.

**Focus states:** use `box-shadow: 0 0 0 2px var(--borderFocus)` — the ring `@acko/checkbox`, `@acko/radio` and `@acko/drawer` ship (TextInput uses the equivalent `outline: 2px solid`). Never remove the focus indicator without a replacement, and never use `--shadowFocusRing` (removed). Buttons and chips use a two-ring variant; see `shadows.md`.

---

## Disabled states

The v1 `disabled/*` group is removed. Use:

| Need | CSS var | Light | Dark |
|---|---|---|---|
| Disabled control / button fill | `--surfaceControlDisabled` | `solidGrey150` | `solidGrey650` |
| Disabled container fill | `--surfaceCardDisabled` | `solidGrey150` | `solidGrey650` |
| Disabled border | `--borderDefaultDisabled` | `alphaGreyA200` | `solidGrey600` |
| Disabled text | `--textDisabled` / `--textDisabledStrong` | `solidGrey250` / `solidGrey300` | `solidGrey500` / `solidGrey450` |
| Fill of a disabled *checked* control | `--surfaceControlDisabledStrong` | `solidGrey300` | `alphaWhiteA200` |
| Icon on a disabled control | `--iconControlDisabled` | `solidGreyWhite` | `alphaWhiteA200` |

---

## Status (surface/status · text/status · border/status · icon/status)

Four families: `error`, `success`, `warning`, `info`. Each spreads across the role families:

| Role | CSS var pattern | Light (error) | Dark (error) |
|---|---|---|---|
| Solid fill | `--surfaceStatus{Family}` | `solidRed500` | `solidRed600` |
| Hover | `--surfaceStatus{Family}Hover` | `solidRed400` | `solidRed600` |
| Subtle fill | `--surfaceStatus{Family}Subtle` | `solidRed100` | `solidRed950` |
| Badge fill | `--surfaceStatus{Family}Badge` | `solidRed100` | `solidRed900` |
| Text | `--textStatus{Family}` | `solidRed700` | `solidRed400` |
| Subtle border | `--borderStatus{Family}Subtle` | `solidRed200` | `solidRed800` |
| Banner gradient | `--surfaceStatus{Family}BannerFrom/To`, `--borderStatus{Family}BannerFrom/To` | `solidRed500` → `solidPink500` | same |

Error-only extras: `--borderStatusError`, `--iconStatusError`, `--surfaceStatusErrorGradientFrom/To`. Info-only: `--surfaceStatusInfoMedium`.

**Warning uses Orange** (`solidOrange*`), not Amber or Yellow.

**Info uses Purple** (`solidPurple*`, fixed — not brand-aware), not Blue.

**Success mixes Green and Lime** — solid fill `solidGreen600`, subtle fill `solidLime100`, text `solidGreen700` (light mode).

---

## Accent (surface/accent · text/accent · border/accent)

For hue-coded components (badges, chips, counters, tags).

```
surface/accent/{hue}            → --surfaceAccent{Hue}             (solid)
surface/accent/{hue}Subtle      → --surfaceAccent{Hue}Subtle
surface/accent/{hue}SubtleAlt   → --surfaceAccent{Hue}SubtleAlt
text/accent/{hue}               → --textAccent{Hue}
border/accent/{hue}             → --borderAccent{Hue}
```

**Available hues:** `purple`, `green`, `blue`, `orange`, `red`, `pink`, `grey`, plus `inverse` (`--surfaceAccentInverse`, `--surfaceAccentInverseAlt`, `--textAccentInverse`, `--borderAccentInverse`).

Green accent uses **Lime** primitives (`solidLime*`) for surfaces and border; light-mode text maps to `solidGreen700`.

---

## icon/

| Figma | CSS var | Light | Dark | When to use |
|---|---|---|---|---|
| `icon/brand/default` † | `--iconBrandDefault` | `brandSelectionDefault` | `brandSelectionDefaultInverse` | Brand-coloured icon |
| `icon/brand/soft` † | `--iconBrandSoft` | `brandSelectionDefaultInverse` | `brandSelectionHover` | Softer brand icon |
| `icon/control/selected` † | `--iconControlSelected` | `brandSelectionOnSelection` | `brandSelectionOnSelection` | Check / dot inside a selected control |
| `icon/control/disabled` | `--iconControlDisabled` | `solidGreyWhite` | `alphaWhiteA200` | Icon on a disabled control |
| `icon/status/error` | `--iconStatusError` | `solidRed700` | `solidRed400` | Error icon |

General icon colours are component tokens (`--iconPrimary`, `--iconSecondary`, `--iconBrand`, … → aliases of the `text/*` tokens) — see `components.md`.

---

## How to pick the right semantic token

```
Is it text?                 → text/*  (text/brand, text/status, text/accent, text/action …)
Is it a page / container?   → surface/page/*, surface/card/*, surface/static/*
Is it a primary button?     → surface/action/*
Is it a selection control?  → surface/control/*
Is it a border?             → border/*
Is it status-driven?        → surface|text|border/status/*
Is it hue-coded?            → surface|text|border/accent/*
Is it disabled?             → surface/control/disabled, text/disabled, border/default/disabled
Is it an icon?              → icon/* (or the --icon* component tokens)
```

---

## Adding a new semantic token

1. Identify the family (`surface`, `text`, `border`, `icon`) and sub-group.
2. Name it `{family}/{group}/{camelCasePurpose}` — no raw color words in the purpose (no "dark", "500"; hue names only inside `accent`).
3. Alias it to `--brand*` (for brand-tinted) or `solid*` / `alpha*` primitives (for neutrals).
4. Set both Light and Dark mode values in `tokens.css`.
5. Set scope: `TEXT_FILL` for text, `FRAME_FILL + SHAPE_FILL` for surfaces, `STROKE_COLOR` for borders.

---

## Legacy → new migration (v1 names removed in 4.0.3)

| Old (removed) | New |
|---|---|
| `--surfaceBase` / `--surfaceBasePrimary` | `--surfacePagePrimary` |
| `--surfaceBaseSecondary` | `--surfacePageSecondary` |
| `--surfaceOverlay` / `--surfaceMuted` / `--surfaceInverted` | `--surfaceOverlayDefault` / `--surfacePageMuted` / `--surfacePageInverse` |
| `--surfaceBrand` | `--surfaceBrandStrong` |
| `--surfaceFillDefault` / `--surfaceFillInput` | `--surfaceCardDefault` / `--surfaceInputDefault` |
| `--surfaceFill{Hover,Active,Muted,Subtle,Ghost}` | `--surfaceCard{Hover,Active,Muted,Subtle,Ghost}` |
| `--fillBrand` / `Hover` / `Active` | `--surfaceActionDefault` / `Hover` / `Active` (buttons) · `--surfaceControlSelected` / `Hover` / `Active` (controls) |
| `--fillBrandSubtle` / `--fillSubtleHover` / `--fillSubtleActive` | `--surfaceBrandSubtle` / `--surfaceBrandSubtleHover` / `--surfaceBrandSubtleActive` |
| `--fillBrandDisabled` | `--surfaceControlDisabled` |
| `--textInvert` / `--textLink` | `--textInverse` / `--textLinkDefault` |
| `--textBrand` / `--textOnBrand` | `--textBrandDefault` / `--textBrandOnBrand` (`--textActionLabel` on buttons) |
| `--borderSoft` / `Subtle` / `Medium` / `Strong` / `Selected` | `--borderDefaultSoft` / `Subtle` / `Medium` / `Strong` / `Selected` |
| `--borderDefault` (grey control border) | `--borderControlDefault` |
| `--borderBrand` / `--borderError` | `--borderBrandSubtle` / `--borderStatusError` |
| `--status{X}Base` / `Text` / `Subtle` | `--surfaceStatus{X}` / `--textStatus{X}` / `--surfaceStatus{X}Subtle` |
| `--accent{Hue}Surface` / `Content` / `Border` | `--surfaceAccent{Hue}Subtle` / `--textAccent{Hue}` / `--borderAccent{Hue}` |
| `--disabledBg` / `--disabledText` / `--disabledBorder` | `--surfaceControlDisabled` / `--textDisabledStrong` / `--borderDefaultDisabled` |
| `--brandPrimary` / `--brandHover` / `--brandActive` | `--brandSelection*` (controls) / `--brandAction*` (buttons) |
| `--brandSubtle` / `--brandRing` / `--brandOnPrimary` | `--brandSurfaceSubtle` / `--brandPrimary200` / `--brandActionOnAction` |
| `--colorPrimary`, `--colorTextPrimary`, `--colorBorder`, … (all `--color*`) | the v2 role token above (e.g. `--surfaceActionDefault`, `--textPrimary`, `--borderControlDefault`) |
| `--greyWhite` / `--purple600` | `--solidGreyWhite` / `--solidPurple600` |

Per-component token mappings → see `components.md`.
