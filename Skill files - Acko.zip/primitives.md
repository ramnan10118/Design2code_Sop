# ACKO Umbrella DS — Primitives

> **Layer 1 of 6.** Raw values only. Never reference Primitives directly from a component or semantic token — always go through Brand (for brand-tinted roles) or Semantics (for neutrals).

**Source of truth:** `@acko/tokens@4.0.3` → `tokens.css` (Figma: *Umbrella DS V1.0 / UM Variable Test*).

---

## What lives here

| Group | Figma path | CSS prefix | Purpose |
|---|---|---|---|
| Solid colors | `Color/Grey/*`, `Color/Purple/*`, … | `--solid{Hue}{step}` | Main hue ramps (50–950) + white/black |
| Accent solids | `Color/Solid/{Hue}/*` | `--solid{Hue}{step}` | Blue, Cyan, Sage, Pink, Orange, Lime, Indigo |
| Alpha | `Color/Alpha/{Hue}A/*` | `--alpha{Hue}A{step}` | Transparency scales |
| Border widths | `border/*` | `--border{Width}` | Raw stroke widths (defined in the Foundations block of `tokens.css`) |
| Elevation | `elevation/*` | `--elevationE{n}` | Raw shadow definitions |

---

## Naming convention

```
Figma:  Color/{Hue}/{step}     →  CSS: --solid{Hue}{step}
Figma:  Color/Alpha/{Hue}A/50 →  CSS: --alpha{Hue}A50

Examples:
  Color/Grey/50          → --solidGrey50
  Color/Purple/600       → --solidPurple600   (ACKO brand hue)
  Color/Green/600        → --solidGreen600    (success / AckoDrive brand hue)
  Color/Alpha/GreyA/A500 → --alphaGreyA500
```

**Available main hues:** Grey, Purple, Green, Red, Amber, Yellow

**Available accent solids:** Blue, Cyan, Sage, Pink, Orange, Lime, Indigo

**Step scale:** most hues ship `50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950`. Extra steps exist only where listed: Purple, Green and Pink add `150` and `850`; Lime adds `150`; Grey uses `50–800` in steps of 50 (no 850/900/950). Never assume a step exists — check the tables below or `tokens.css`.

Special:
- `Color/Grey/White` → `--solidGreyWhite` (`#ffffff`)
- `Color/Grey/Black` → `--solidGreyBlack` (`#000000`) — there is no `--solidGrey900`

---

## Grey (Color/Grey) — Figma exact values

| Figma | CSS var | Hex |
|---|---|---|
| White | `--solidGreyWhite` | `#ffffff` |
| 50 | `--solidGrey50` | `#fafafa` |
| 100 | `--solidGrey100` | `#f5f5f5` |
| 150 | `--solidGrey150` | `#efeff0` |
| 200 | `--solidGrey200` | `#dcdcdc` |
| 250 | `--solidGrey250` | `#cccbcd` |
| 300 | `--solidGrey300` | `#b7b7b8` |
| 350 | `--solidGrey350` | `#8f8e92` |
| 400 | `--solidGrey400` | `#7a787d` |
| 450 | `--solidGrey450` | `#605f63` |
| 500 | `--solidGrey500` | `#474649` |
| 550 | `--solidGrey550` | `#292829` |
| 600 | `--solidGrey600` | `#1e1e1f` |
| 650 | `--solidGrey650` | `#19191a` |
| 700 | `--solidGrey700` | `#141414` |
| 750 | `--solidGrey750` | `#0f0f10` |
| 800 | `--solidGrey800` | `#0a0a0a` |
| Black | `--solidGreyBlack` | `#000000` |

---

## Purple (Color/Purple)

ACKO brand anchors: `#f8f5ff` (50) · `#6841e6` (600) · `#2d1362` (950). Components never use these directly — the ACKO brand reaches them through `--brandPrimary*` (see `semantics.md` → Brand layer).

| Figma | CSS var | Hex |
|---|---|---|
| 50 | `--solidPurple50` | `#f8f5ff` |
| 100 | `--solidPurple100` | `#f2ebff` |
| 150 | `--solidPurple150` | `#ebe2fe` |
| 200 | `--solidPurple200` | `#d9cefd` |
| 300 | `--solidPurple300` | `#bca8fa` |
| 400 | `--solidPurple400` | `#987cf4` |
| 500 | `--solidPurple500` | `#7f5dee` |
| 600 | `--solidPurple600` | `#6841e6` |
| 700 | `--solidPurple700` | `#5a1fd4` |
| 800 | `--solidPurple800` | `#491ba5` |
| 850 | `--solidPurple850` | `#40198f` |
| 900 | `--solidPurple900` | `#371678` |
| 950 | `--solidPurple950` | `#2d1362` |

---

## Green (Color/Green)

Used for success states and as the AckoDrive brand hue (`[data-brand="ackodrive"]`).

| Figma | CSS var | Hex |
|---|---|---|
| 50 | `--solidGreen50` | `#f0fdf4` |
| 100 | `--solidGreen100` | `#e3fdec` |
| 150 | `--solidGreen150` | `#cbfbdc` |
| 200 | `--solidGreen200` | `#bbf7d0` |
| 300 | `--solidGreen300` | `#86efac` |
| 400 | `--solidGreen400` | `#4ade80` |
| 500 | `--solidGreen500` | `#27c05f` |
| 600 | `--solidGreen600` | `#16a34a` |
| 700 | `--solidGreen700` | `#15803d` |
| 800 | `--solidGreen800` | `#145c2f` |
| 850 | `--solidGreen850` | `#124a28` |
| 900 | `--solidGreen900` | `#07401f` |
| 950 | `--solidGreen950` | `#052e16` |

---

## Red (Color/Red)

| Figma | CSS var | Hex |
|---|---|---|
| 50 | `--solidRed50` | `#fff5f5` |
| 100 | `--solidRed100` | `#ffe6e6` |
| 200 | `--solidRed200` | `#fecaca` |
| 300 | `--solidRed300` | `#fca5a5` |
| 400 | `--solidRed400` | `#f87171` |
| 500 | `--solidRed500` | `#ef4444` |
| 600 | `--solidRed600` | `#dc2626` |
| 700 | `--solidRed700` | `#b91c1c` |
| 800 | `--solidRed800` | `#991b1b` |
| 900 | `--solidRed900` | `#7f1d1d` |
| 950 | `--solidRed950` | `#450a0a` |

---

## Amber (Color/Amber) — warnings

| Figma | CSS var | Hex |
|---|---|---|
| 50 | `--solidAmber50` | `#fffbeb` |
| 100 | `--solidAmber100` | `#fef3c7` |
| 200 | `--solidAmber200` | `#fde68a` |
| 300 | `--solidAmber300` | `#fcd34d` |
| 400 | `--solidAmber400` | `#fbbf24` |
| 500 | `--solidAmber500` | `#f59e0b` |
| 600 | `--solidAmber600` | `#d97706` |
| 700 | `--solidAmber700` | `#b45309` |
| 800 | `--solidAmber800` | `#92400e` |
| 900 | `--solidAmber900` | `#78350f` |
| 950 | `--solidAmber950` | `#451a03` |

---

## Yellow (Color/Yellow) — highlights only, not warnings

| Figma | CSS var | Hex |
|---|---|---|
| 50 | `--solidYellow50` | `#fefae8` |
| 100 | `--solidYellow100` | `#fef9c3` |
| 200 | `--solidYellow200` | `#fef08a` |
| 300 | `--solidYellow300` | `#fde047` |
| 400 | `--solidYellow400` | `#facc15` |
| 500 | `--solidYellow500` | `#eab308` |
| 600 | `--solidYellow600` | `#d18c0a` |
| 700 | `--solidYellow700` | `#a76406` |
| 800 | `--solidYellow800` | `#875008` |
| 900 | `--solidYellow900` | `#62360f` |
| 950 | `--solidYellow950` | `#302012` |

---

## Accent solids (Color/Solid/*)

Each accent hue follows the 50–950 scale (Pink adds 150/850, Lime adds 150). CSS prefix matches hue name:

| Hue | CSS prefix | Example |
|---|---|---|
| Blue | `--solidBlue*` | `--solidBlue600` = `#2563eb` |
| Cyan | `--solidCyan*` | `--solidCyan600` = `#0891b2` |
| Sage | `--solidSage*` | `--solidSage600` = `#48735e` (Acko Clinic secondary hue) |
| Pink | `--solidPink*` | `--solidPink600` = `#db2777` (Acko Clinic brand hue) |
| Orange | `--solidOrange*` | `--solidOrange600` = `#eb740a` |
| Lime | `--solidLime*` | `--solidLime600` = `#45a316` |
| Indigo | `--solidIndigo*` | `--solidIndigo600` = `#4f46e5` |

Full hex values ship in `@acko/tokens/tokens.css`.

---

## Alpha scales (Color/Alpha/*)

Every alpha scale uses the steps `00, 50, 100, 150, 200, 300, 400, 500, 600, 700, 800, 900, 950`.

| Scale | CSS prefix | Format |
|---|---|---|
| GreyA (black alpha) | `--alphaGreyA{step}` | `rgba(0,0,0, …)` — A50 = 0.05 … A950 = 0.95 |
| WhiteA | `--alphaWhiteA{step}` | `rgba(255,255,255, …)` — same opacities as GreyA |
| PurpleA | `--alphaPurpleA{step}` | `rgba(153,116,249, …)` — ACKO brand tints (via `--brandAlpha*`) |
| RedA | `--alphaRedA{step}` | `rgba(239,68,68, …)` up to A400; A500+ use `rgba(220,38,38, …)` — error overlays |

Tinted scales (A50 = 0.04 … A950 = 0.96) also ship for `OrangeA`, `YellowA`, `GreenA`, `LimeA`, `CyanA`, `AmberA`, `BlueA`, `PinkA`, `IndigoA` and `TealA` (`--alpha{Hue}A{step}`). There are no fine-grained aliases (`--alphaGreyA04` etc. were removed).

**Common uses (always through the semantic token):**
- `--alphaGreyA400` / `--alphaGreyA500` — modal scrim, light / dark (`--surfaceOverlayDefault`)
- `--alphaPurpleA300` — focus ring tint in both themes (`--brandAlphaMedium` → `--borderFocus`)

---

## Border (raw widths)

| Figma | CSS var | Value |
|---|---|---|
| `border/none` | `--borderNone` | `0rem` |
| `border/hairline` | `--borderHairline` | `0.0625rem` (1px) |
| `border/control` | `--borderControl` | `0.125rem` (2px) |
| `border/heavy` | `--borderHeavy` | `0.25rem` (4px) |

---

## Elevation (raw shadows)

| Figma | CSS var | Value |
|---|---|---|
| `elevation/e0` | `--elevationE0` | `none` |
| `elevation/e1` | `--elevationE1` | `0 1px 4px rgba(0,0,0,0.06)` |
| `elevation/e2` | `--elevationE2` | `0 2px 8px rgba(0,0,0,0.06)` |
| `elevation/e3` | `--elevationE3` | `0px 2px 16px 4px rgba(0,0,0,0.04)` |
| `elevation/e4` | `--elevationE4` | `0 4px 24px rgba(0,0,0,0.10)` |
| `elevation/e5` | `--elevationE5` | `0 8px 32px rgba(0,0,0,0.12)` |

Role aliases: `--elevationCard` (E3), `--elevationPopover` (E2), `--elevationModal` (E4). Effect-style shadows: `--shadowXs`, `--shadowS`, `--shadowM`, `--shadowL`, `--shadowXl` — see `shadows.md`.

---

## Rules

1. **Never import Primitives into a component directly.** Components → Semantics → Brand → Primitives.
2. **Never use Primitives for stroke/fill on a canvas layer.** The variable scope is intentionally hidden from pickers.
3. **Adding a new hue?** Add the full 50–950 ramp here first, then create Brand aliases, then wire into Semantics.
4. **Step naming:** always numeric (`600`), never words like `dark` or `light` — those belong in Semantics role names.
5. **Legacy names removed in 4.0.3:** `--solidPrimary{n}` → `--solidPurple{n}` · `--solidSecondary{n}` → `--solidGreen{n}` · `--alphaPrimaryA{n}` → `--alphaPurpleA{n}` · `--solidGrey900` → `--solidGreyBlack` · `--solidTeal*` → gone (use `--solidCyan*`; `--alphaTealA*` remains) · fine-grained alphas (`--alphaGreyA04`) → nearest `--alphaGreyA{step}`. Older `--grey50`, `--purple600`, `--blackA7` also do not exist.
