---
description: Spacing, sizing, opacity, z-index, and utility tokens — numeric foundation for the design system
---

# Spacing & Sizing

All numeric foundations for the design system: spacing, component sizing, and utility tokens. All tokens on this page are **theme-agnostic** — they do not change between themes.

## Spacing System

Spacing is powered by Tailwind v4 utilities with a **1px base**:

```css
/* @acko/tokens/theme.css (4.0.3) */
@theme inline {
  --spacing: 0.0625rem; /* 1px at 16px root */
}
```

**The utility number equals the pixel value.** No math, no indirection:

- `gap-12` = 12px
- `p-16` = 16px
- `h-48` = 48px
- `w-240` = 240px

Because the base is `0.0625rem` (1/16 of a rem), all spacing scales proportionally with the root font-size. A consumer app can use `clamp()` on `html { font-size }` and every spacing/sizing utility will scale fluidly.

### Rules

1. **Never use `var(--scale-*)` or `var(--space-*)`** — these tokens do not exist
2. **Never use raw `px` values** for spacing — use a Tailwind utility (`@apply p-16`) or, in plain CSS, the matching `--spacing{N}` token (`padding: var(--spacing16)`), which is how `@acko/css` itself is written
3. **Never use the old 4px-multiplier mapping** (`gap-2` for 8px is wrong; use `gap-8`)
4. All spacing in component CSS goes through `@apply` or `var(--spacing{N})` — zero inline `px` values for gaps, padding, margins, or dimensions. `--spacing{N}` tokens exist for `0, 1, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 64, 80, 96`; for any other size use the utility (`w-240`)
5. **Icon `size-*` utilities follow the same 1px scale** — `size-16` = 16px, `size-24` = 24px; `size-4` = 4px (not 16px). Standalone `@acko/icons` need explicit `size-*`. See `iconography.md`.

## Spacing Reference

Use Tailwind utilities directly. The number is the pixel value.

| Utility | Pixels | Use Case |
|---------|--------|----------|
| `gap-4` / `p-4` | 4px | Micro gaps |
| `gap-8` / `p-8` | 8px | Icon padding, tight gaps, inline elements |
| `gap-12` / `p-12` | 12px | Form field gaps, small component padding |
| `gap-16` / `p-16` | 16px | Standard padding, card gaps, button padding |
| `gap-20` / `p-20` | 20px | Medium gaps, `<Surface padding="md">` |
| `gap-24` / `p-24` | 24px | `<Surface padding="lg">`, section gaps |
| `gap-28` | 28px | Component internal spacing |
| `gap-32` | 32px | Large component gaps |
| `gap-36` | 36px | Section padding |
| `gap-40` | 40px | Large spacing |
| `gap-48` | 48px | Section margins |
| `gap-64` | 64px | Page sections |
| `gap-80` | 80px | Hero spacing |
| `gap-96` | 96px | Large section breaks |

## Component Sizing Scale

Fixed heights for interactive components — use `h-*` utilities:

| Utility | Pixels | Used by |
|---------|--------|---------|
| `h-32` | 32px | Button xs |
| `h-36` | 36px | InputGroup sm |
| `h-40` | 40px | Button sm, TextInput sm, Dropdown sm |
| `h-44` | 44px | InputGroup md, min tap target |
| `h-48` | 48px | Button md, TextInput md, Dropdown md |
| `h-52` | 52px | InputGroup lg |
| `h-56` | 56px | Button lg, TextInput lg, Dropdown lg |
| `h-64` | 64px | Button xl |

## Inter-Component Spacing

| Between | Utility |
|---------|---------|
| Label and input | `gap-4` (4px, built into TextInput) · `gap-8` in a `Form` item |
| Input and helper/error text | `gap-4` (4px, built into TextInput) |
| Form fields | `gap-16` (16px, `Form` default) |
| Section heading and content | `gap-32` (32px) |
| Cards in a grid | `gap-16` mobile, `gap-24` desktop |
| Buttons in a group | `gap-12` (12px) |
| Icon and adjacent text | `gap-8` (8px) |

## Tailwind Utility Examples

Utility numbers map 1:1 to pixels. Steps that have a `--spacing{N}` token resolve to it (`theme.css` maps `--spacing-16: var(--spacing16)`); any other number falls back to `calc(var(--spacing) * N)`:

| Intent | Utility | CSS Output |
|--------|---------|------------|
| 8px gap | `gap-8` | `gap: var(--spacing8)` → 8px |
| 16px padding | `p-16` | `padding: var(--spacing16)` → 16px |
| 48px height | `h-48` | `height: var(--spacing48)` → 48px |
| 40px height | `h-40` | `height: var(--spacing40)` → 40px |
| 56px height | `h-56` | `height: var(--spacing56)` → 56px |
| 240px width | `w-240` | `width: calc(var(--spacing) * 240)` → 240px |
| 12px margin-top | `mt-12` | `margin-top: var(--spacing12)` → 12px |

### Anti-patterns

| Don't | Do |
|-------|----|
| `gap-2` for 8px (old 4px base) | `gap-8` for 8px |
| `h-12` for 48px (old 4px base) | `h-48` for 48px |
| `gap-[var(--scale8)]` | `gap-8` |
| `padding: var(--scale16)` | `@apply p-16` or `padding: var(--spacing16)` |
| `width: 240px` | `@apply w-240` |
| `height: 48px` | `@apply h-48` |

## Opacity Scale (`--opacity-*`)

Direct decimal values from 0 to 1. The token number represents the percentage (e.g., `--opacity48` = 0.48). Tailwind: `opacity-48`.

| Token | Value | | Token | Value |
|-------|-------|-|-------|-------|
| `--opacity0` | 0 | | `--opacity56` | 0.56 |
| `--opacity4` | 0.04 | | `--opacity64` | 0.64 |
| `--opacity8` | 0.08 | | `--opacity72` | 0.72 |
| `--opacity16` | 0.16 | | `--opacity84` | 0.84 |
| `--opacity24` | 0.24 | | `--opacity96` | 0.96 |
| `--opacity32` | 0.32 | | `--opacity100` | 1 |
| `--opacity48` | 0.48 | | | |

Only these 13 steps exist in 4.0.3 — the in-between steps (`--opacity2`, `6`, `10`, `12`, `20`, `28`, `36`, `40`, `44`, `52`, `80`, `88`) were removed; use the nearest step.

## Z-Index Scale (`--z-*`)

| Token | Value | Use Case |
|-------|-------|----------|
| `--zDropdown` | 1000 | Dropdown menus, select popups |
| `--zSticky` | 1100 | Sticky headers, floating elements |
| `--zModal` | 1300 | Modal dialogs, sheets |
| `--zToast` | 1400 | Toast notifications |
| `--zTooltip` | 1500 | Tooltips, popovers |

## Responsive Breakpoints

See `layout.md` for the canonical breakpoint definitions, section containers, gutters, and full-bleed rules.

| Name | Range | Media Query |
|------|-------|-------------|
| Mobile | 0 – 767px | Base styles (no media query) |
| Tablet | 768px – 1023px | `@media (min-width: 768px)` |
| Desktop | ≥ 1024px | `@media (min-width: 1024px)` |

## Border Widths (`--border*`)

| Token | Value | Use Case |
|-------|-------|----------|
| `--borderNone` | `0rem` | No border |
| `--borderHairline` | `0.0625rem` (1px) | Card, surface, input and badge strokes — `border: var(--borderHairline) solid …` |
| `--borderControl` | `0.125rem` (2px) | Control emphasis strokes |
| `--borderHeavy` | `0.25rem` (4px) | Heavy accents |

`--borderHairline` is a fixed 1px (rem-based, so it scales with the root font-size) — there is no retina 0.5px override. `--borderControl` is a width only; the control border *colour* is `--borderControlDefault` (see `semantics.md`).
