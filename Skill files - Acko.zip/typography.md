---
description: Typography — font family, role-based text styles, weight rules, sizing, and the <Typography> component API
globs: "**/*.css,**/*.tsx"
alwaysApply: true
---

# Typography

Token definitions, component API, and usage rules for all text in ACKO products. Applies to `@acko/typography`, `@acko/css` and `@acko/tokens` **4.0.3**.

## Rule — Never Use Raw HTML Text Tags

Never use `<h1>`, `<h2>`, `<h3>`, `<h4>`, `<h5>`, `<h6>`, `<p>`, `<span>`, `<label>` for text rendering. Always use `<Typography textStyle="...">` from `@acko/typography`.

```tsx
// ❌ Never do this
<h1 style={{ fontSize: "clamp(2rem, 5vw, 3rem)", fontWeight: 700 }}>
  Car insurance that protects you
</h1>

// ✅ Always do this
<Typography textStyle="display-xl">
  Car insurance that protects you
</Typography>
```

## Import

```tsx
import { Typography } from "@acko/typography";
// Also exported: TEXT_STYLES (array of every textStyle) and the TextStyle / TypographyColor / TypographyAlign types
```

## Props

| Prop | Type | Required | Notes |
|------|------|----------|-------|
| `textStyle` | `TextStyle` | ✅ Yes | Always required. Size, line-height, letter-spacing **and weight** all come from it |
| `color` | `TypographyColor` | No | Default `primary`. Use instead of inline color styles |
| `align` | `"left" \| "center" \| "right"` | No | Default `left`. Use instead of inline `textAlign` |
| `as` | `React.ElementType` | No | Override the rendered HTML tag |
| `truncate` | `boolean` | No | Single-line truncation with ellipsis |
| `italic` | `boolean` | No | Italic style |
| `underline` | `boolean` | No | Underline |
| `className` | `string` | No | For Tailwind utility classes only |

There is **no `variant` prop and no `weight` prop** in 4.0.3. Weight is part of the text style name (`body-md-regular`, `body-md-medium`, `body-md-semibold`). To change weight, pick a different text style.

Default element when `as` is omitted: `display-*` → `<h1>`, `heading-xl` / `heading-2xl` → `<h2>`, other `heading-*` → `<h3>`, `body-*` / `article-*` → `<p>`, `label-*` / `helper-*` → `<span>`.

## Font Family

**Euclid Circular B** — all text across the system. Per-brand font token: `--brandTypefaceFont` (`--typefaceFamily` is a legacy alias of it).

```css
font-family: 'Euclid Circular B', -apple-system, BlinkMacSystemFont, sans-serif;
```

CDN base: `https://pub-c050457d48794d5bb9ffc2b4649de2c1.r2.dev/Euclid%20Font/`

`@acko/tokens/tokens.css` declares `@font-face` for Light (300) through Bold (700), with italics. The text styles only use three weights: **Regular (400), Medium (500), Semibold (600)** — tokens `--typefaceWeightRegular`, `--typefaceWeightMedium`, `--typefaceWeightSemibold`. There is no Bold weight token.

## Text Styles

44 role-based styles in six categories. Each one is a CSS class `.acko-text-{textStyle}` in `@acko/css/typography.css`, built from the `--typefaceSize*`, `--typefaceLineHeight*` and `--typefaceWeight*` tokens in `@acko/tokens/tokens.css`. Letter-spacing has no token — it is set per style in the class.

### Display (marketing, heroes) — all Semibold 600

| textStyle | Size | Line Height | Letter Spacing |
|-----------|------|-------------|----------------|
| `display-2xl` | 60px (3.75rem) | 64px | -1.2px |
| `display-xl` | 48px (3rem) | 52px | -0.96px |
| `display-lg` | 40px (2.5rem) | 44px | -0.6px |
| `display-md` | 32px (2rem) | 36px | -0.32px |

### Heading (UI sections, card titles) — all Semibold 600

| textStyle | Size | Line Height | Letter Spacing |
|-----------|------|-------------|----------------|
| `heading-2xl` | 28px | 36px | -0.14px |
| `heading-xl` | 24px | 30px | -0.12px |
| `heading-lg` | 20px | 26px | -0.1px |
| `heading-md` | 16px | 22px | -0.08px |
| `heading-sm` | 14px | 20px | 0 |
| `heading-xs` | 12px | 16px | 0 |

### Body (running text, descriptions)

| textStyle | Size | Line Height | Weights |
|-----------|------|-------------|---------|
| `body-lg-*` | 16px | 24px | `regular`, `medium` |
| `body-md-*` | 14px | 20px | `regular`, `medium`, `semibold` |
| `body-sm-*` | 12px | 18px | `regular`, `medium` |

### Label (UI labels, controls, values)

| textStyle | Size | Line Height | Weights | Letter Spacing |
|-----------|------|-------------|---------|----------------|
| `label-3xl-semibold` | 28px | 34px | `semibold` only | -0.14px |
| `label-2xl-*` | 20px | `normal` | `regular`, `medium`, `semibold` | 0 |
| `label-xl-*` | 18px | 24px | `regular`, `medium`, `semibold` | 0 |
| `label-lg-*` | 16px | 22px | `regular`, `medium`, `semibold` | 0 |
| `label-md-*` | 14px | 20px | `regular`, `medium`, `semibold` | 0 |
| `label-sm-*` | 12px | 16px | `regular`, `medium`, `semibold` | 0 |
| `label-xs-*` | 10px | 14px | `regular`, `medium`, `semibold` | 0.1px |

### Helper (captions, footnotes, helper text)

| textStyle | Size | Line Height | Weights | Letter Spacing |
|-----------|------|-------------|---------|----------------|
| `helper-sm-*` | 12px | 16px | `regular`, `medium` | 0 |
| `helper-xs-*` | 10px | 14px | `regular`, `medium` | 0.1px |

### Article (long-form reading — generous line-height)

| textStyle | Size | Line Height | Weights |
|-----------|------|-------------|---------|
| `article-lg-*` | 16px | 26px | `regular`, `semibold` |
| `article-md-*` | 14px | 24px | `regular`, `semibold` |

`*` = the weight suffix. Only the combinations listed exist — e.g. there is no `body-lg-semibold` or `helper-sm-semibold`. The full list is the `TEXT_STYLES` export.

### Example usage in CSS

Prefer `<Typography>`. When you must style a non-React element, apply the class (`class="acko-text-heading-xl"`) or use the same tokens the class uses:

```css
.my-heading {
  font-size: var(--typefaceSize2xl);         /* 24px */
  line-height: var(--typefaceLineHeightXl);  /* 30px */
  font-weight: var(--typefaceWeightSemibold);
  letter-spacing: -0.12px;                   /* = heading-xl */
}
```

## Tailwind Mapping

Tailwind's `text-*` sizes carry their own line-heights, which don't match the ACKO text styles — prefer `<Typography>` or an `acko-text-*` class.

| Token | Tailwind equivalent |
|-------|-------------------|
| 10px / `--typefaceSize2xs` | `text-[10px]` |
| 12px / `--typefaceSizeXs` | `text-xs` |
| 14px / `--typefaceSizeSm` | `text-sm` |
| 16px / `--typefaceSizeBase` | `text-base` |
| 18px / `--typefaceSizeLg` | `text-lg` |
| 20px / `--typefaceSizeXl` | `text-xl` |
| 24px / `--typefaceSize2xl` | `text-2xl` |
| Weight 400 | `font-regular` (or `font-normal`) |
| Weight 500 | `font-medium` |
| Weight 600 | `font-semibold` |

## Button Font Sizes (Intentionally Hardcoded)

Buttons use their own scale — set in `@acko/css/button.css`, not via `<Typography>`. All Medium (500):

| Size | Font | Matches | Tailwind |
|------|------|---------|----------|
| xs | 12px | Label/SM | `text-xs` |
| sm | 14px | Label/MD | `text-sm` |
| md | 16px | Label/LG | `text-base` |
| lg | 18px | Label/XL | `text-lg` |
| xl | 20px | Label/2XL | `text-xl` |

## Text Styles — Component Usage

### Display (hero headings, marketing headlines)
```tsx
<Typography textStyle="display-2xl">Largest hero heading</Typography>
<Typography textStyle="display-xl">Primary hero heading</Typography>
<Typography textStyle="display-lg">Secondary hero heading</Typography>
<Typography textStyle="display-md">Smaller hero heading</Typography>
```

### Heading (section titles, card titles)
```tsx
<Typography textStyle="heading-2xl">Page section title</Typography>
<Typography textStyle="heading-xl">Sub-section title</Typography>
<Typography textStyle="heading-lg">Card title</Typography>
<Typography textStyle="heading-md">Small card title or step title</Typography>
<Typography textStyle="heading-sm">List group heading</Typography>
```

### Body (paragraphs, descriptions)
```tsx
<Typography textStyle="body-lg-regular">Lead paragraph or subtitle</Typography>
<Typography textStyle="body-md-regular">Default body text</Typography>
<Typography textStyle="body-sm-regular">Small supporting text</Typography>
<Typography textStyle="body-md-medium">Emphasised body text, alert titles</Typography>
```

### Label (UI labels, values, controls)
```tsx
<Typography textStyle="label-lg-medium">Large UI label</Typography>
<Typography textStyle="label-md-medium">Default UI label</Typography>
<Typography textStyle="label-sm-medium">Small UI label</Typography>
<Typography textStyle="label-3xl-semibold">₹2,094</Typography> {/* large amounts */}
```

### Helper & Article
```tsx
<Typography textStyle="helper-sm-regular">Fine print, timestamps, metadata, field hints</Typography>
<Typography textStyle="article-md-regular">Long-form reading — policy wording, T&Cs, help articles</Typography>
```

## Weight

Weight is chosen by the text style's suffix — there is no `weight` prop:

```tsx
textStyle="body-md-regular"   // default body text (400)
textStyle="body-md-medium"    // slightly emphasised (500)
textStyle="body-md-semibold"  // strong emphasis (600)
textStyle="heading-lg"        // display & heading styles are always Semibold (600)
```

## Color Values

The `color` prop uses 7 intent-based values:

| Value | 4.0.3 token for this intent | Use case |
|-------|-------|----------|
| `primary` (default) | `--textPrimary` | General use — headings, values, main content |
| `secondary` | `--textSecondary` | Subtext — captions, helpers, descriptions |
| `invert` | `--textInverse` | Text on dark/filled surfaces (opposite of current theme) |
| `brand` | `--textBrandDefault` | Brand-colored text — links, emphasis |
| `error` | `--textStatusError` | Error messages |
| `success` | `--textStatusSuccess` | Success messages |
| `static` | `--textStaticLight` | Fixed color across themes — white in both light and dark |

All tokens except `static` auto-adapt across light and dark themes. `static` produces an identical color (`--solidGreyWhite`) in both themes — use it for text that must remain fixed regardless of theme (e.g., white text on a photo overlay).

> **Known issue in `@acko/css` 4.0.3:** the `invert`, `brand`, `error` and `success` classes still point at pre-v2 variable names that `tokens.css` no longer defines, so without a fix, text with those colors inherits its parent's color. The ACKO boilerplate's `src/index.css` ships a compatibility shim that maps these to 4.0.3 tokens. Keep that block; if a project wasn't set up from the boilerplate, copy it in.

## Common Patterns

### Hero section heading + subtext
```tsx
<Typography textStyle="display-xl">
  Car insurance that protects you, not just your car
</Typography>
<Typography textStyle="body-lg-regular" color="secondary">
  Get comprehensive cover starting at ₹2,094/year.
</Typography>
```

### Section title + supporting text
```tsx
<Typography textStyle="heading-2xl">
  Why ACKO is different
</Typography>
<Typography textStyle="body-lg-regular" color="secondary">
  Built from scratch as a digital insurer.
</Typography>
```

### Card title + description
```tsx
<Typography textStyle="heading-lg">
  Instant digital policy
</Typography>
<Typography textStyle="body-md-regular" color="secondary">
  Buy in 2 minutes flat. No paperwork.
</Typography>
```

### Form label
```tsx
{/* Same style TextInput and Dropdown use for their md label.
    For a real <label htmlFor>, use @acko/label or the input's own label prop. */}
<Typography textStyle="body-md-medium">
  Car registration number
</Typography>
```

### Eyebrow + headline
```tsx
<Typography textStyle="label-sm-semibold" color="brand">
  Trusted by 50 lakh+ car owners
</Typography>
<Typography textStyle="display-lg" as="h2">
  Insurance built for people who hate insurance
</Typography>
```

### Caption / fine print
```tsx
<Typography textStyle="helper-sm-regular" color="secondary">
  IRDAI Licence No. 157 · No spam. No follow-up calls.
</Typography>
```

## Rules

- Minimum 14px for running body text (`body-md-*`, `article-md-*`), 12px for supporting text and labels (`body-sm-*`, `label-sm-*`, `helper-sm-*`); 10px (`*-xs-*`) is the absolute minimum — badges, counters and micro labels only
- Medium (500) for emphasis in body — pick the `-medium` style. Use `body-md-semibold` only for strong emphasis
- Display and heading styles are always Semibold (600). Bold (700) is not part of any text style — never apply it
- Letter-spacing is baked into each style (negative on display and large headings, +0.1px on `xs`) — don't override it
- Use `text-wrap: balance` on headings
- `font-variant-numeric: tabular-nums` for dynamic numbers
- **Never hardcode** `fontSize`, `fontWeight`, `lineHeight`, or `letterSpacing` in inline styles
- **Never use** `clamp()` for font sizing — responsive sizing is a text-style swap in CSS (see responsiveness.md)
- **Never use** `color` in inline styles for text — use the `color` prop instead
- **Always pick** the closest text style to your intent — do not approximate with raw styles
- **Use `as` prop** when semantic HTML matters but visual style differs:

```tsx
// Renders as <h1> but styled as heading-lg
<Typography textStyle="heading-lg" as="h1">
  Page title
</Typography>
```

Typography tokens are **theme-agnostic** — they do not change between themes.

## Rendering Rules

```css
body {
  font-family: 'Euclid Circular B', -apple-system, BlinkMacSystemFont, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

h1, h2, h3 { text-wrap: balance; }
p { text-wrap: pretty; }
```

- One `h1` per screen — every `display-*` style renders `<h1>` by default, so pass `as="h2"` (or similar) to any second display-styled text
- Never rely on color alone for hierarchy — size and weight first
- Never change font weight on hover (causes layout shift)

## Font Loading

`@acko/tokens/tokens.css` already loads Euclid Circular B from the CDN with `font-display: swap`. Preload the critical file from the same URL:

```html
<link rel="preload" href="https://pub-c050457d48794d5bb9ffc2b4649de2c1.r2.dev/Euclid%20Font/EuclidCircularB-Regular.otf" as="font" type="font/opentype" crossorigin />
```

## Text Casing

All UI text must follow **sentence case** — capitalize only the first word and proper nouns/exceptions. This applies across the entire system: headings, buttons, labels, tabs, breadcrumbs, navigation items, links, badges, and toast actions.

> Capitalize only the first word of a text label. All other words are lowercase unless they are proper nouns or fall under the exceptions below.

### Examples

**Correct**

- `Get a quote`
- `View my policy`
- `Continue to payment`
- `Check IDV`
- `Claim your NCB`
- `Pay with ACKO Drive`
- `Find clinics near Bengaluru`

**Incorrect**

- `Get A Quote`
- `View My Policy`
- `Continue To Payment`
- `Check Idv`
- `Claim Your NCB`
- `find clinics near bengaluru`

### Exceptions

These terms always retain their defined casing regardless of position in the label.

#### Brand names

- `ACKO` — always all-caps
- `ACKO [Product]` — sub-brands retain their casing (e.g., `ACKO Drive`, `ACKO Clinic`)

#### Proper nouns

City names, state names, country names, and person names retain their standard capitalization. Sentence case applies to common nouns and verbs — not proper nouns.

- `Check plans in Hyderabad` — correct
- `Check plans in hyderabad` — incorrect
- `Aadhaar` — always capitalized as a proper noun (not `AADHAAR` or `aadhaar`)

#### Regulatory & government bodies

- `IRDAI` — Insurance Regulatory and Development Authority of India

#### Insurance & financial acronyms

- `IDV` — Insured Declared Value
- `NCB` — No Claim Bonus
- `KYC` — Know Your Customer
- `GST` — Goods and Services Tax
- `EMI` — Equated Monthly Instalment
- `OTP` — One Time Password

#### Identity & document acronyms

- `PAN` — Permanent Account Number

### All-caps emphasis

Words like `FREE`, `NEW`, `SAVE` must remain lowercase in button, label, and navigation text. Call them out with a `<Badge>` next to the text instead — not with caps in the label.

- `Get a free quote` — correct (button)
- `Get a FREE quote` — incorrect (button)
- `Free` — correct (inside a `<Badge>`)

### Common nouns

Product and coverage terms like `premium`, `claim`, `policy`, `cover` are common nouns — always lowercase unless they start the sentence.

### Where this applies

| Component | Applies? |
|-----------|----------|
| Button labels | Yes |
| Tab labels | Yes |
| Breadcrumb text | Yes |
| Navigation items | Yes |
| Link text | Yes |
| Toast action labels | Yes |
| Dialog action buttons | Yes |
| Headings | Yes |
| Badge | Yes — `@acko/badge` 4.0.3 has no `textCase` prop and renders the label exactly as written (Figma badge labels are sentence case) |
