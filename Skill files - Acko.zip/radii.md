---
description: Border radius tokens and nested radius rule
---

# Border Radius Tokens

Source: `@acko/tokens@4.0.3` → `tokens.css` (Tailwind keys in `theme.css`). Note the Tailwind keys are **remapped** to ACKO values — e.g. `rounded-3xl` is 16px here, not Tailwind's default 24px.

| Token | Value | Use Case | Tailwind |
|-------|-------|----------|----------|
| `--radiusZero` | 0px | Square corners | `rounded-zero` |
| `--radiusSm` | 4px | Nested insets, checkbox sm, skeleton text | `rounded-sm` |
| `--radiusMd` | 6px | Checkboxes md/lg, dropdown options | `rounded-md` |
| `--radiusLg` | 8px | Alerts, calendar panel | `rounded-lg` |
| `--radiusXl` | 10px | — | `rounded-xl` |
| `--radius2xl` | 12px | Textarea, OTP input cells | `rounded-2xl` |
| `--radius3xl` | 16px | Dropdown menus, `CardNote`, inset `CardMedia` | `rounded-3xl` |
| `--radius4xl` | 20px | Dialogs, drawers | `rounded-4xl` |
| `--radius5xl` | 24px | Cards (`--brandRadiusCard`) | `rounded-5xl` / `rounded-brand-card` |
| `--radius6xl` – `--radius9xl` | 28 / 32 / 40 / 48px | Extra-large surfaces | `rounded-6xl` – `rounded-9xl` |
| `--radiusFull` | 9999px | Buttons (`--brandRadiusButton`), inputs, pills, badges, chips | `rounded-full` / `rounded-brand-button` |

**`--radius5xl` (24px)** is the standard for cards — `@acko/card` ships it, and `--brandRadiusCard` points to it. Dialogs and drawers use `--radius4xl` (20px); dropdown menu panels use `--radius3xl` (16px). `<Surface>` has no radius of its own.

## Nested Radius Rule

When a rectangular element is nested inside a rounded container:

```
inner radius = outer radius − padding
```

Card outer radius is `--radius5xl` (24px). There are no inset-radius tokens — compute the inner radius and pick the matching token:

| Container padding | Inner radius | Token |
|-------|-------|------|
| 12px | 24 − 12 = 12px | `--radius2xl` |
| 16px (`CardBody` default) | 24 − 16 = 8px | `--radiusLg` |
| 24px | 24 − 24 = 0px | `--radiusZero` |

### Applies to
- Icon wrapper boxes, image thumbnails, inset panels you build inside a card

### Exempt (keep their own radius)
- Buttons, badges, avatars — intentional pill/circular shape
- `@acko/card` parts that ship their own radius (`CardNote`, inset `CardMedia` use `--radius3xl`; bleed `CardMedia` follows the card edge) — don't override them

Radius tokens are **theme-agnostic**.

**Legacy removed:** `--radiusInsetSm`, `--radiusInsetMd`, `--radiusInsetLg` → compute from the table above.
