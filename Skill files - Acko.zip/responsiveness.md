---
description: ACKO responsiveness — how typography, layout, and components adapt across mobile, tablet, and desktop. Read before designing or building any screen.
globs: "**/*.tsx,**/*.css,**/*.md"
alwaysApply: true
---

# ACKO Responsiveness

Three rules:

1. **Type downshifts on mobile** — large display/heading text styles render smaller. Body, labels, helper text stay put.
2. **Layout rearranges** — horizontal stacks go vertical, grids collapse to one column, CTAs go full-width.
3. **Components downshift** — heavy patterns swap to lighter ones. Table → cards. Top nav → hamburger. Dialog → bottom drawer.

Spacing never changes — same scale (scales.md) at every breakpoint. Layout does the work.

---

## Breakpoints

Mobile-first, min-width only. Never mix with max-width.

| Name | Range | Query |
|------|-------|-------|
| Mobile | 0–599px | Base (no query) |
| Tablet | 600–1023px | min-width: 600px |
| Desktop | 1024px+ | min-width: 1024px |

Tablet inherits the desktop type scale — type only downshifts below 600px. Desktop is safe at 1366px, comfortable to 1920px+.

> These breakpoints supersede the 768/1024 values in layout.md/scales.md until reconciled. This file wins for new work.

---

## 1. Typography — text style swap below 600px

Six large text styles swap to a smaller existing style. Nothing else changes, no new tokens created.

| textStyle | Desktop | Mobile renders as | Mobile size |
|-------|---------|--------------------|-------------|
| display-2xl | 3.75rem/60px | display-lg | 2.5rem/40px |
| display-xl | 3rem/48px | display-md | 2rem/32px |
| display-lg | 2.5rem/40px | heading-2xl | 1.75rem/28px |
| display-md | 2rem/32px | heading-xl | 1.5rem/24px |
| heading-2xl | 1.75rem/28px | heading-xl | 1.5rem/24px |
| heading-xl | 1.5rem/24px | heading-lg | 1.25rem/20px |

heading-lg and below, and every body/label/helper/article style, are unchanged at every breakpoint — body is already at the 12–16px floor.

The Typography component's `textStyle` prop stays the same; the swap happens in CSS, not viewport checks in code.

### What the swap touches

The downshift CSS overrides exactly three properties: **font-size, line-height, letter-spacing.** Never font-weight.

Weight belongs to the text style, not the breakpoint — every display and heading style is Semibold (600), and body/label/helper/article styles carry their weight in the name (`-regular`, `-medium`, `-semibold`). There is no `weight` prop. A downshift rule that copies the mobile target wholesale, font-weight included, is at best redundant and at worst silently changes weight if the pattern is reused on a weight-suffixed style. `display-xl` must stay 600 at every breakpoint; only its size/line-height/letter-spacing shift toward `display-md`'s values.

Mobile-first: the mobile values are the base rule, and a `min-width: 600px` query restores the style's own values. Load this CSS after `@acko/css`.

```css
/* Correct — three properties only */
.acko-text-display-xl {
  font-size: var(--typefaceSize5xl);          /* display-md: 2rem */
  line-height: var(--typefaceLineHeight4xl);  /* 2.25rem */
  letter-spacing: -0.32px;
  /* font-weight intentionally omitted — it comes from the text style */
}

@media (min-width: 600px) {
  .acko-text-display-xl {
    font-size: var(--typefaceSize8xl);          /* display-xl: 3rem */
    line-height: var(--typefaceLineHeight7xl);  /* 3.25rem */
    letter-spacing: -0.96px;
  }
}
```

Values for every style in the swap table (from `@acko/css/typography.css`). Letter-spacing has no token — copy the value:

| textStyle | font-size | line-height | letter-spacing |
|-----------|-----------|-------------|----------------|
| display-2xl | `--typefaceSize10xl` | `--typefaceLineHeight10xl` | -1.2px |
| display-xl | `--typefaceSize8xl` | `--typefaceLineHeight7xl` | -0.96px |
| display-lg | `--typefaceSize7xl` | `--typefaceLineHeight6xl` | -0.6px |
| display-md | `--typefaceSize5xl` | `--typefaceLineHeight4xl` | -0.32px |
| heading-2xl | `--typefaceSize3xl` | `--typefaceLineHeight4xl` | -0.14px |
| heading-xl | `--typefaceSize2xl` | `--typefaceLineHeightXl` | -0.12px |
| heading-lg | `--typefaceSizeXl` | `--typefaceLineHeightMd` | -0.1px |

**Rules:** never hardcode font size/line-height/letter-spacing in inline styles or component overrides — use the `--typeface*` tokens above · downshift CSS must never set font-weight · no clamp() for font sizing · never shrink body text on mobile · needing display-2xl at 60px on a phone means pick a smaller text style, not an exception.

### Picking text styles in constrained contexts

The swap table is a size ladder within the display/heading families, not a rule that every style shrinks somewhere. Two things to check before choosing a text style:

- **It has to be in the table to downshift.** `heading-lg` is the floor of the chain — `heading-xl` downshifts *to* `heading-lg`, but `heading-lg` itself never moves. If a piece of text needs to shrink on mobile, it must use a style one step up the chain (`heading-xl`, not `heading-lg`), not the target it would land on.
- **Display styles assume hero-scale space.** They're sized for marketing sections with room to breathe, so their downshift deltas are large (e.g. `display-xl` 48px→32px). Dropping a display style into a tight container — a card, a list row — will read as a jarring, disproportionate drop even though it's working as designed. In dense UI, prefer the heading family, which has smaller steps, or pair two styles that are both meant to move together (e.g. `heading-xl` name + `heading-xl` price, not `heading-lg` name + `display-md` price) so hierarchy stays coherent at both breakpoints.

---

## 2. Layout — three rearrangements

- **Horizontal → vertical** below 600px: hero CTA rows, feature rows, list items with trailing actions, form-field pairs.
- **Grids collapse**:

| Desktop cols | Tablet | Mobile |
|---|---|---|
| 4 | 2 | 1 |
| 3 | 2 | 1 |
| 2 | 2 | 1 |

- **CTAs full-width** below 600px (inline links excluded).

---

## 3. Component downshifts — heavy → light

| Desktop | Mobile | Why |
|---------|--------|-----|
| Data table | Stacked cards | Tables need horizontal room |
| Top nav bar | Hamburger menu | Doesn't fit a 390px screen |
| Centered dialog | Bottom drawer | One-thumb reach |
| Large dropdown | Bottom drawer | Same thumb-reach reason |
| Multi-column form | Single-column form | Fields need full width to tap |

Use the packages' built-in components (`Dialog` from `@acko/dialog` → `Drawer side="bottom"` from `@acko/drawer`) rather than one-off swaps. A squeezed-down dialog is not a bottom drawer — it must be the actual component.

---

## Non-negotiable

1. Every screen checked at ≤390px, ~768px, ≥1366px before shipping.
2. No hardcoded font size, spacing, or column count — flow through tokens/layout system.
3. Min-width only, never max-width.
4. Never shrink body text on mobile (12–16px floor; 14px+ for running text).
5. No horizontal scroll on mobile.
6. Tap targets ≥44px (see touch-accessibility.md).
7. Downshift CSS never sets font-weight — weight stays constant across breakpoints regardless of text style.

---

## Checklist

- [ ] Tested at 390px, 768px, 1366px
- [ ] Type downshifts per swap table
- [ ] Body/labels/helper text unchanged across breakpoints
- [ ] Font weight identical at every breakpoint for a given element
- [ ] Horizontal stacks → vertical below 600px
- [ ] Grids collapse per column table
- [ ] CTAs full-width on mobile
- [ ] Tables → cards, nav → hamburger, dialogs → bottom drawers
- [ ] No horizontal scroll
- [ ] Tap targets ≥44px
