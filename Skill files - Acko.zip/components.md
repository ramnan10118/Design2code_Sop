# ACKO Umbrella DS — Component Tokens

> **Layer 6 of 6.** One token per component role. Single `Value` mode — Light/Dark resolves automatically through the alias chain (Component → Semantics → Brand → Primitives). Never holds raw values.

**Source of truth:** `@acko/tokens@4.0.3` → `tokens.css` (Component Tokens section). Shipped variant mappings: `@acko/css@4.0.3` → `<component>.css`.

---

## The rule

Every component token is exactly one alias — to a **Semantics** token wherever one matches the Figma value in both Light and Dark (or to another component token, e.g. `--dropdownBorder → --inputFieldBorder`). Only when no semantic token matches does it alias a **Brand** token (e.g. `--sliderTrackActiveFrom → --brandSelectionDefault`). No per-mode entries. No RGB literals.

```
Figma path                    CSS var                         Alias chain
button/fill/primaryDefault → --buttonFillPrimaryDefault  →  --surfaceActionDefault → --brandActionDefault → --brandPrimary950 → --solidPurple950
inputField/fill            → --inputFieldFill            →  --surfaceInputDefault → --solidGreyWhite
card/fill/default          → --cardFillDefault           →  --surfaceCardDefault → --solidGreyWhite
```

**v1 component token names are removed in 4.0.3.** Always use the names below. Renames that matter: `--chip*` → `--chipSelector*` · `--switch*` → `--toggle*` · `--badgeCountText` → `--badgeCountTextLight` / `--badgeCountTextDark` · `--inputFieldBorderError` → `--inputFieldBorderErrorTop` / `--inputFieldBorderErrorBottom` · `--radioBorderSelected` → `--radioBorderSelectedTop` / `--radioBorderSelectedBottom` · `--progressLabelText` → `--progressLabel` · `--calendarDateOutOfMonth` → `--calendarDateMuted` · `--drawerBg` → `--bottomSheetSurface`. Removed with no replacement: `--cardFillHighlight`, `--cardFillDisable`, `--cardBorderDisable`, `--surfacePrimaryBg`, `--surfaceSecondaryBg`, `--dialogBg`, `--skeletonBase`, `--paginationActiveBg`, `--toastInfoSurface` (and the rest of those groups).

---

## Naming convention

```
Figma path                      CSS var (camelCase, no slashes)
{component}/{role}              e.g. buttonFillPrimaryDefault
{component}/{role}{State}       e.g. buttonFillPrimaryHover
{component}/{subgroup}/{role}   e.g. alertInfoSurface
```

- Figma uses `/` grouping; CSS uses camelCase with component prefix
- Never embed color words (`purple`, `green`) — embed role words (`brand`, `danger`, `selected`)

---

## All component tokens (Figma → CSS var)

### accordion/
`--accordionBodyText` · `--accordionBorder` · `--accordionFill` · `--accordionFillHover` · `--accordionHeaderHover` · `--accordionIcon` · `--accordionTitleText` · `--accordionTitleHover` · `--accordionTitleDisabled`

### alert/
`--alertBodyText`

Per severity — maps to `--alert{Severity}{Role}` (Severity = Info, Success, Warning, Error):
`Surface` · `Border` · `Text` · `Icon` · `GradientFrom` · `GradientVia` · `GradientTo` · `BorderFrom` · `BorderTo`
e.g. `--alertErrorSurface` · `--alertErrorBorder` · `--alertErrorText` · `--alertErrorIcon` · `--alertErrorGradientFrom` · `--alertErrorBorderTo`

### avatar/
`--avatarFill` · `--avatarText` · `--avatarNameText` · `--avatarSubtext` · `--avatarStatusOnline` · `--avatarStatusOffline` · `--avatarStatusAway`
`--avatarStoryRing` · `--avatarStoryGap` · `--avatarProgressRing` · `--avatarProgressTrack`

### badge/
`--badgeCountTextLight` · `--badgeCountTextDark`

Per hue — `--badge{Hue}{Role}` (Hue = Purple, Green, Blue, Orange, Red, Pink, Grey, Black):
`Fill` · `Icon` · `Text` · `GradientFrom` · `GradientTo` · `CounterFill`

_(Only Grey adds `Border` · `Outline`. Black has no `CounterFill`.)_

### bottomSheet/ (used by `@acko/drawer`)
`--bottomSheetSurface` · `--bottomSheetScrim` · `--bottomSheetTitle` · `--bottomSheetDescription` · `--bottomSheetContent` · `--bottomSheetHandle`

### breadcrumb/
`--breadcrumbText` · `--breadcrumbLink` · `--breadcrumbLinkHover` · `--breadcrumbCurrent` · `--breadcrumbSeparator`

### button/
Maps to `@acko/button` variants: `primary`, `secondary`, `ghost`, `link`, `destructive-low`, `destructive-high`, `primary-on-dark`, `secondary-on-dark`, `ghost-on-dark`, `link-on-dark`, `destructive-on-dark`, `white`, `translucent`.

**Fill:** `--buttonFillPrimaryDefault/Hover/Active/Disabled/Text` · `--buttonFillSecondaryDefault/Hover/Active/Disabled/Text/Border` · `--buttonFillGhostDefault/Hover/Active/Disabled/Text` · `--buttonFillDangerDefault/Hover/Active/Disabled` · `--buttonFillDangerHighDefault/Hover/Active/Text` · `--buttonFillDangerLowText` · `--buttonFillLinkText/TextHover/TextPressed/TextDisabled`

**Fill — dark / static surfaces:** `--buttonFillPrimaryOnDarkDefault/Hover/Active/Disabled/Text` · `--buttonFillSecondaryOnDarkHover/Active/Text` · `--buttonFillGhostOnStaticDefault/Hover/Active/Disabled/Text/TextDisabled` · `--buttonFillDangerOnStaticDefault/Hover/Active/Disabled/Text/TextDisabled` · `--buttonFillLinkOnStaticText/TextHover/TextPressed/TextDisabled` · `--buttonFillWhiteDefault/Hover/Active/Disabled/Text/TextDisabled` · `--buttonFillTranslucentDefault/Hover/Active/Disabled/Text/TextDisabled`

**Border:** `--buttonBorderSecondaryDefault/Disabled` · `--buttonBorderSecondaryOnDarkDefault/Disabled` · `--buttonBorderDefaultGradientTop/Bottom` · `--buttonBorderDangerDefault` · `--buttonBorderDangerOnStaticDefault` · `--buttonBorderWhiteDefault`

**Other:** `--buttonTextDisabled` · `--buttonTextOnStaticDisabled` · `--buttonFocusRingInner/Outer` · `--buttonFocusRingOnStaticInner/Outer` · `--buttonFillNotificationDot` · `--buttonBorderNotificationDot`
**Loading:** `--buttonLoadingSpinnerOn{Solid,Subtle,Danger,Static,StaticSolid}` · `--buttonLoadingTrackOn{Solid,Subtle,Danger,Static,StaticSolid}`

### calendar/
`--calendarBorder` · `--calendarDayLabel` · `--calendarWeekday` · `--calendarNavIcon` · `--calendarDateDefault` · `--calendarDateMuted`
`--calendarSelectedBg` · `--calendarSelectedBackground` · `--calendarSelectedBorder` · `--calendarSelectedText` · `--calendarRangeBand` · `--calendarRangeBg` · `--calendarRangeText`
`--calendarHoverBg` · `--calendarCellHoverBg` · `--calendarTodayText` · `--calendarTodayBorder`

### card/
**Fill:** `--cardFillDefault` · `--cardFillMuted` · `--cardFillAccent` · `--cardFillHover` · `--cardFillGhost` · `--cardFillStaticWhite` · `--cardFillStaticBlack`
**Border:** `--cardBorderDefault` · `--cardBorderSecondary` · `--cardBorderBrand`

**`@acko/card` + `@acko/css@4.0.3` variant mapping:**

| `variant` | Fill | Border | Shadow |
|---|---|---|---|
| `"primary"` | `--cardFillDefault` | `--cardBorderDefault` | `--shadowXs` |
| `"secondary"` | `--cardFillDefault` | `--cardBorderSecondary` | none |
| `"muted"` | `--cardFillMuted` | `--cardBorderSecondary` | none |
| `"accent"` | `--cardFillAccent` | `--cardBorderSecondary` | none |
| `"ghost"` | `--cardFillGhost` | none | none |

All borders are `--borderHairline` wide. Tappable cards (`onTap`) switch to `--cardFillHover` while pressed. Fix wrong-looking colours in the token alias in `@acko/tokens`, not in `card.css`.

### surface/ (`@acko/surface`)
No `--surface*Bg` component tokens — `surface.css` reads semantic tokens directly.

**`@acko/surface` variant mapping (Figma / `specs` intent):**

| `variant` | Fill token | Border |
|---|---|---|
| `"primary"` | `--surfacePagePrimary` ¹ | none |
| `"secondary"` | `--surfacePageSecondary` ¹ | none |
| `"staticBlack"` | `--surfaceStaticBlack` | `--cardBorderSecondary` |
| `"staticWhite"` | `--surfaceStaticWhite` | `--cardBorderSecondary` |
| `"brand"` | `--surfacePageBrand` ¹ | `--cardBorderSecondary` |
| `"brandLight"` | `--surfaceBrandLight` | `--cardBorderSecondary` |
| `"inverted"` | `--surfacePageInverse` ¹ | `--cardBorderSecondary` |

No shadow and no radius on any variant (square corners). `padding`: `sm` 12px · `md` 20px · `lg` 24px.

¹ `surface.css` 4.0.3 still reads the removed v1 names `--surfaceBasePrimary`, `--surfaceBaseSecondary`, `--surfaceBrand` and `--surfaceInverted`, so without a fix these four variants render with no background. The ACKO boilerplate's `src/index.css` ships a compatibility shim that maps these to 4.0.3 tokens. Keep that block; if a project wasn't set up from the boilerplate, copy it in.

**Page vs component:** Page primary background = `--surfacePagePrimary` (flat). Page secondary bands = **`<Surface variant="secondary">`** (full-bleed: `w-full`; inset: inside `section-container`). Do not hand-apply page tokens to bands when `@acko/surface` is available.

### checkbox/
`--checkboxFill` · `--checkboxFillChecked` · `--checkboxFillDisabled` · `--checkboxFillDisabledChecked`
`--checkboxBorder` · `--checkboxBorderHover` · `--checkboxBorderFocus` · `--checkboxBorderError` · `--checkboxBorderSelectedTop` · `--checkboxBorderSelectedBottom`
`--checkboxCheck` · `--checkboxDisabled` · `--checkboxDisabledIcon`

### chipSelector/ (used by `@acko/chip`)
`--chipSelectorOutlineBg` · `--chipSelectorBgHover` · `--chipSelectorActiveBg` · `--chipSelectorPressedBg` · `--chipSelectorSelectedBg` · `--chipSelectorDisabledBg`
`--chipSelectorText` · `--chipSelectorHoverText` · `--chipSelectorActiveText` · `--chipSelectorSelectedText` · `--chipSelectorDisabledText`
`--chipSelectorBorder` · `--chipSelectorHoverBorder` · `--chipSelectorPressedBorder` · `--chipSelectorSelectedBorder` · `--chipSelectorDisabledBorder`
`--chipSelectorIcon` · `--chipSelectorSelectedIcon` · `--chipSelectorDisabledIcon`

### counter/
Per hue — `--counter{Hue}GradientFrom` · `--counter{Hue}GradientTo` · `--counter{Hue}Border` (Pink, Purple, Blue)

### dropdown/
`--dropdownFill` · `--dropdownFillDisabled` · `--dropdownBg`
`--dropdownBorder` · `--dropdownBorderHover` · `--dropdownBorderError`
`--dropdownLabeltext` · `--dropdownLabelTextActive` · `--dropdownLabelTextDisabled`
`--dropdownPlaceholderText` · `--dropdownFilledText` · `--dropdownFilledTextDisabled`
`--dropdownHelperText` · `--dropdownHelperTextError` · `--dropdownHelperTextSuccess`
`--dropdownIcon` · `--dropdownIconDisabled` · `--dropdownCheckIcon` · `--dropdownFocusRing`
`--dropdownPanelFill` · `--dropdownPanelBorder` · `--dropdownOptionFill` · `--dropdownOptionFillDisabled` · `--dropdownOptionHover` · `--dropdownOptionSelectedBg` · `--dropdownOptionSelectedText` · `--dropdownOptionText` · `--dropdownOptionTextDisabled`

### icon/
`--iconPrimary` · `--iconSecondary` · `--iconTertiary` · `--iconDisabled` · `--iconInvert`
`--iconBrand` · `--iconLink` · `--iconError` · `--iconStaticLight` · `--iconStaticDark`

### inputField/ (used by `@acko/text-input`)
`--inputFieldFill` · `--inputFieldFillDisabled`
`--inputFieldBorder` · `--inputFieldBorderHover` · `--inputFieldBorderFilled` · `--inputFieldBorderFocus` · `--inputFieldBorderErrorTop` · `--inputFieldBorderErrorBottom`
`--inputFieldLabeltext` · `--inputFieldLabelTextActive` · `--inputFieldLabelTextDisabled`
`--inputFieldPlaceholderText` · `--inputFieldFilledText` · `--inputFieldFilledTextDisabled`
`--inputFieldHelperText` · `--inputFieldHelperTextError` · `--inputFieldHelperTextSuccess`
`--inputFieldIconSuccess` · `--inputFieldFocusRing`

### otp/ (used by `@acko/otp-input`)
`--otpFill` · `--otpFillDisabled` · `--otpFocusFill`
`--otpBorder` · `--otpBorderDisabled` · `--otpBorderError` · `--otpBorderErrorBottom` · `--otpFocusBorder`
`--otpLabeltext` · `--otpLabelTextDisabled`
`--otpDigitText` · `--otpDigitTextDisabled`
`--otpHelperText` · `--otpHelperTextError` · `--otpHelperTextSuccess`

### progress/
`--progressTrack` · `--progressFill` · `--progressDisable`
`--progressLabel` · `--progressLabelDisabled` · `--progressValue` · `--progressValueDisabled` · `--progressHelperText`

### radio/
`--radioFill` · `--radioFillChecked` · `--radioFillDisabled` · `--radioCardSelected`
`--radioBorder` · `--radioBorderHover` · `--radioBorderFocus` · `--radioBorderError` · `--radioBorderDisabled` · `--radioBorderSelectedTop` · `--radioBorderSelectedBottom`
`--radioCheck` · `--radioDisabledIcon`

### separator/
`--separatorLine` · `--separatorLineStrong` · `--separatorLabelText`

### slider/
`--sliderThumbBg` · `--sliderThumbBgDisabled` · `--sliderThumbStrokeFrom` · `--sliderThumbStrokeTo` · `--sliderThumbStrokeFocus` · `--sliderThumbStrokeDisabled`
`--sliderTrackActiveFrom` · `--sliderTrackActiveTo` · `--sliderTrackInactive` · `--sliderTrackDisabled`
`--sliderFillDisabledFrom` · `--sliderFillDisabledTo`

### toggle/ (used by `@acko/switch`)
`--toggleFill` · `--toggleFillOn` · `--toggleFillDisabled` · `--toggleThumb` · `--toggleThumbDisabled`

There are no `--switch*` tokens — `switch.css` reads these.

### track/
`--trackInactive`

### textarea/
Same pattern as inputField — prefix `--textarea*` instead of `--inputField*`, with two differences: one `--textareaBorderError` (no Top/Bottom pair) and no `BorderFocus` token.

### Token-only groups (no package in the boilerplate)
**table/** `--tableBorder` · `--tableBorderHeader` · `--tableHeaderBg` · `--tableHeaderText` · `--tableRowFill` · `--tableRowFillSelected` · `--tableRowHover` · `--tableStripe` · `--tableCellText`
**tabs/** `--tabsPillBg` · `--tabsPillActiveBg` · `--tabsPillActiveText` · `--tabsPillOuterBorder` · `--tabsTextInactive` · `--tabsTextDisabled` · `--tabsItemText` · `--tabsItemTextHover` · `--tabsItemTextSelected` · `--tabsItemTextDisabled` · `--tabsIndicator` · `--tabsIndicatorHover` · `--tabsIndicatorActive` · `--tabsCountBg` · `--tabsCountText` · `--tabsBarBorder` · `--tabsFocusRing`
**tooltip/** `--tooltipBg` · `--tooltipText`
**wizard/** `--wizardActiveBg` · `--wizardActiveShadowTop` · `--wizardActiveShadowBottom` · `--wizardActiveText` · `--wizardDoneBg` · `--wizardDoneText` · `--wizardConnectorDone` · `--wizardConnectorUpcoming` · `--wizardUpcomingBorder` · `--wizardUpcomingText`
**segmented/** `--segmentedTrackBg` · `--segmentedSegmentText` · `--segmentedSegmentTextSelected` · `--segmentedSegmentTextDisabled` · `--segmentedSegmentFillHover` · `--segmentedSegmentFillActive` · `--segmentedSegmentFillSelected`
**pilltabs/** `--pilltabsOutlineBg` · `--pilltabsBgHover` · `--pilltabsDisabledBg` · `--pilltabsBorder` · `--pilltabsSelectedBorder` · `--pilltabsDisabledBorder` · `--pilltabsText` · `--pilltabsSelectedText` · `--pilltabsDisabledText` · `--pilltabsIcon` · `--pilltabsSelectedIcon` · `--pilltabsDisabledIcon`

### dialog / skeleton
No component tokens. `@acko/dialog`, `@acko/skeleton` (and `@acko/toggle`, `@acko/form`, `@acko/label`, `@acko/input-group`) ship CSS in 4.0.3 that still reads removed v1 `--color*` tokens, so their colours fall back to transparent / inherited. The boilerplate shim covers dialog and skeleton. When styling around them, use semantic tokens (`--surfaceCardDefault`, `--surfaceOverlayDefault`, `--textPrimary`, `--borderDefaultSubtle`) — never reintroduce `--color*` names.

---

## Adding a new component token

1. Identify the semantic role it maps to (see `semantics.md`).
2. Name it `{component}/{camelCaseRole}` — no color words, no theme words.
3. Create in the **Components** collection (single `Value` mode).
4. Set its value to a `VARIABLE_ALIAS` pointing to a **Semantics** token. Alias a Brand token only when no semantic token matches in both Light and Dark. Never point to Primitives directly.
5. Set scope: `TEXT_FILL`, `FRAME_FILL + SHAPE_FILL`, or `STROKE_COLOR` — never `ALL_SCOPES`.
6. Bind the canvas layer to this component token (not to the Semantics token directly).

## When NOT to create a new component token

- If two components need the exact same role (e.g. both use `text/primary` for body copy) — **reuse the semantic token directly** only if no component-specific token exists yet, then create one for each component pointing to that same semantic.
- Never add a token for a hard-coded value like white or black — use `text/staticLight` / `text/staticDark` or `surface/staticWhite` / `surface/staticBlack`.
