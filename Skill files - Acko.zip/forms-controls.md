# Forms & Controls

Patterns for inputs, buttons, validation, and form structure. All spacing and sizing values reference tokens from `primitives.md`.

---

## The ACKO Forms Rule

Insurance forms are the core of the product. Users fill these out when buying, claiming, or renewing — often on mobile, sometimes stressed, often first-timers. Every form decision must reduce friction, not add it.

---

## Inputs

### Labels

Always associate labels with inputs. Prefer the `label` prop on `@acko/text-input`, `@acko/textarea` and `@acko/dropdown` — it renders the label (`body-md-medium`; `body-lg-medium` at `size="lg"`) and links it via `htmlFor`. Hand-built labels use `<Typography textStyle="body-md-medium">`. Never use placeholder text as a label substitute.

```html
<label for="vehicle-number">Vehicle number</label>
<input id="vehicle-number" type="text" />
```

### Input Types

Always use the correct `type` — controls mobile keyboard.

```html
<input type="email" />    <!-- Email keyboard -->
<input type="tel" />      <!-- Numeric dialpad — phone, vehicle numbers, policy IDs -->
<input type="number" />   <!-- Number keyboard -->
<input type="password" /> <!-- Masked -->
```

`@acko/text-input` sets `type`, `inputMode`, `autoComplete` and `maxLength` from `inputType`: `email`, `phone` (+91 prefix), `number`, `pincode`, `aadhaar`, `pan`, `registrationNumber` (plate mask), `password`, and more.

### Font Size — iOS Zoom Prevention

Input font size must be at least 16px (`body-lg-regular`; `body-md` is 14px in 4.0.3). Smaller sizes trigger auto-zoom on iOS. `@acko/text-input` and `@acko/dropdown` render 16px text at the default `size="md"` and 14px at `size="sm"` — don't use `sm` for mobile forms.

### Autocomplete

Enable for known user data (`email`, `tel`). Disable for OTPs, policy numbers, vehicle numbers:

```html
<input autocomplete="off" spellcheck="false" />
```

### Prefilling

Always prefill with known user data — name, phone, email, vehicle number, address.

### Input Decorations

With `@acko/text-input`, use the `prefix` (e.g. "₹"), `suffix`, `leftIcon` and `rightIcon` props — the field sizes and spaces them. Hand-built: icons and currency symbols absolutely positioned over input. Icon left offset → `p-16`. Input left padding when icon present → `p-40`.

### Autofocus

Autofocus when a modal opens if its primary purpose is input. Never autofocus on touch devices.

```jsx
const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
<input autoFocus={!isTouchDevice} />
```

---

## Forms

- Always wrap inputs in `<form>` so Enter submits
- Support `Cmd+Enter` / `Ctrl+Enter` for textareas
- Multi-step: show progress indicator, preserve state on back, validate on step exit, scroll to first error
- `@acko/form` exports `Form`, `FormItem`, `FormLabel`, `FormMessage`, `useFormContext`. `Form` renders `<form noValidate>`, tracks `state` (`idle | submitting | success | error`) and sets `aria-busy` while `onSubmit` runs. `FormItem name="…"` shows the error set with `useFormContext().setError(name, { message })` as `role="alert"` text; `FormMessage` is helper text, hidden while that item has an error. `form.css` 4.0.3 still colours that text with removed v1 tokens (it renders uncoloured), so for field errors prefer the field's own `errorText` and use `FormItem` errors for cross-field / server messages

### Validation Timing

| Scenario | When to Validate |
|----------|-----------------|
| Required field empty | On blur |
| Format error (email, phone) | On blur |
| Cross-field errors | On submit |
| Server-side errors | Immediately on response |

Never validate on every keystroke.

---

## Buttons

- Always use `<button>`, never `div` or `span` with click handlers
- Always set `type` explicitly (`submit` or `button`). `@acko/button` defaults to `type="button"`, so the submit CTA needs `type="submit"`
- Disable after submission with loading copy. `<Button loading>` disables the button and swaps the label for a three-dot loader, so show the loading copy in nearby status text

### CTA Copy Rules

| Instead of | Use |
|------------|-----|
| Submit | Continue / Confirm / Buy now |
| Click here | View my policy / Start claim |
| OK | Got it / Done |
| Cancel | Go back / Not now |
| Yes / No | Specific label ("Delete claim" / "Keep claim") |

### Loading State Copy

| Action | Loading Copy |
|--------|-------------|
| Form submit | Processing... |
| Payment | Securing payment... |
| Document upload | Uploading... |
| Policy fetch | Fetching your policy... |

---

## Error Handling

- Errors live directly below the field. Use `helper-sm-regular`, `--textStatusError`, `gap-4` — or pass `errorText` to `@acko/text-input` / `@acko/textarea` / `@acko/dropdown`, which renders it with `role="alert"` and the error border (`error` alone sets the state without a message). `@acko/otp-input` takes `errorText` too
- Specific: "Enter a 10-digit mobile number" — not "Invalid phone number"
- Solution-oriented, never blame the user, never technical language

```jsx
<input
  id="phone"
  type="tel"
  aria-invalid={!!errors.phone}
  aria-describedby={errors.phone ? 'phone-error' : undefined}
/>
{errors.phone && (
  <span id="phone-error" role="alert">{errors.phone}</span>
)}
```

### Server Errors

```jsx
catch (error) {
  setError("We couldn't process this right now. Please try again in a moment.");
}
```

---

## Destructive Actions

Use a proper confirmation modal — never `window.confirm()`. Destructive CTA always comes second.

```jsx
<Dialog
  open={open}
  onClose={close}
  title="Cancel this claim?"
  footer={
    <>
      <Button variant="ghost">Keep claim</Button>
      <Button variant="destructive-high">Cancel claim</Button>
    </>
  }
>
  Your documents will be deleted.
</Dialog>
```

---

## Checkboxes and Toggles

Entire row (label + control) must be clickable — `@acko/checkbox` and `@acko/switch` render the row as a `<label>`, so pass `label` instead of placing text beside the control. Gap: `gap-12` (12px, what both components use). Never pre-check consent boxes.

---

## OTP Inputs

- Auto-advance on digit entry
- `autocomplete="one-time-code"` on first field for SMS auto-fill
- Minimum 44px per digit cell — `@acko/otp-input` cells are 40 / 48 / 56px (`sm` / `md` / `lg`), so use `md` (default) or `lg`. Gap: `gap-8` (`gap-12` at `lg`)
- `@acko/otp-input` already does all of this: `<OtpInput value={otp} onChange={setOtp} length={6} errorText={...} resendIn={timerText} onResend={...} />`

```jsx
<input
  type="tel"
  maxLength={1}
  inputMode="numeric"
  autoComplete={index === 0 ? 'one-time-code' : 'off'}
/>
```
