---
description: Shadow tokens — primitive and semantic shadows for elevation hierarchy
---

# Shadow Tokens

**Source of truth:** `@acko/tokens@4.0.3` → `tokens.css`

---

## Primitive elevation (Figma: elevation/*)

| Figma | CSS var | Value |
|---|---|---|
| `elevation/e0` | `--elevationE0` | `none` |
| `elevation/e1` | `--elevationE1` | `0 1px 4px rgba(0,0,0,0.06)` |
| `elevation/e2` | `--elevationE2` | `0 2px 8px rgba(0,0,0,0.06)` |
| `elevation/e3` | `--elevationE3` | `0px 2px 16px 4px rgba(0,0,0,0.04)` |
| `elevation/e4` | `--elevationE4` | `0 4px 24px rgba(0,0,0,0.10)` |
| `elevation/e5` | `--elevationE5` | `0 8px 32px rgba(0,0,0,0.12)` |

---

## Effect-style shadows (Figma: Effect Styles)

| CSS var | Tailwind | Use Case |
|---|---|---|
| `--shadowXs` | `shadow-xs` | Primary card elevation (`<Card variant="primary">`) |
| `--shadowS` | `shadow-s` | Light elevation |
| `--shadowM` | `shadow-m` | Medium elevation |
| `--shadowL` | `shadow-l` | Dialogs, sheets |
| `--shadowXl` | `shadow-xl` | Modals, popovers |

`--shadowXs` value:
```css
0px 5px 10px 0px rgba(0,0,0,0.02),
0px 18px 18px 0px rgba(0,0,0,0.02)
```

`<Surface>` variants are flat — no shadow on any variant.

**Legacy names removed:** `--shadowSm`, `--shadowMd`, `--shadowLg`, `--shadow2xl` → use `--shadowS`, `--shadowM`, `--shadowL`, `--shadowXl`.

---

## Semantic shadow aliases

| Token | Maps to | Tailwind | Use Case |
|---|---|---|---|
| `--elevationCard` | `--elevationE3` | `shadow-card` | Card-level elevation |
| `--elevationPopover` | `--elevationE2` | `shadow-popover` | Small popovers |
| `--elevationModal` | `--elevationE4` | `shadow-modal` | Dropdown menu panel, drawers (what `@acko/dropdown` and `@acko/drawer` ship) |

`--elevationDropdown` was removed — use `--elevationModal`.

---

## Inner shadows

| CSS var | Value |
|---|---|
| `--shadowInnerS` | `inset 0px 2px 4px -1px rgba(0,0,0,0.24)` |
| `--shadowInnerM` | `inset 0px 2px 4px -1px rgba(0,0,0,0.24)` |
| `--shadowInnerL` | `inset 0px 2px 4px -1px rgba(0,0,0,0.24)` |

---

## Focus ring

Use the semantic border focus token — **not** a dedicated shadow token:

```css
:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--borderFocus);
}
```

`--borderFocus` → `--brandAlphaMedium` → `alphaPurpleA300` (both themes; brand-aware)

Component-scoped focus rings alias the same semantic:
- `--inputFieldFocusRing` → `--borderFocus`
- `--textareaFocusRing` → `--borderFocus`
- `--dropdownFocusRing` → `--borderFocus` (also used by tappable `Card` / `Surface`)
- `--checkboxBorderFocus`, `--radioBorderFocus` → `--borderFocus`

Buttons and chips use a two-ring focus (page-coloured gap, then the brand ring):

```css
box-shadow:
  0 0 0 2px var(--buttonFocusRingInner),   /* --surfacePagePrimary */
  0 0 0 4px var(--buttonFocusRingOuter);   /* --borderFocus */
```

**Legacy removed:** `--shadowFocusRing`, `--colorPrimaryRing`

---

## Badge gradient pattern

Solid badges use a flat hue fill with a 1px **vertical gradient stroke** — no shadows:

```css
border: 1px solid transparent;
background:
  linear-gradient(var(--badgePurpleFill), var(--badgePurpleFill)) padding-box,
  linear-gradient(180deg, var(--badgePurpleGradientFrom), var(--badgePurpleGradientTo)) border-box;
```

Counter badges: `--counter{Pink,Purple,Blue}GradientFrom/To/Border`

---

## Rules

- Shadow tokens are theme-agnostic (defined once on `:root`) — on dark surfaces lean on surface contrast and `--borderDefaultSoft` rather than a heavier shadow
- Prefer `box-shadow` over `border` for hairline edges
- Never use harsh drop shadows — keep them diffused
- Never remove the focus indicator — use `box-shadow: 0 0 0 2px var(--borderFocus)`
