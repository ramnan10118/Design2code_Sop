# ACKO Card System

**Layer 3** of the design system — card grammar for composing contextual UI surfaces.

```
scales.md → semantics.md → components → cards.md
Raw values      Color roles    Atom components  Card grammar
```

> **Rule for LLM generation:** Every card must use a `Card` variant from the shell spec, compose from the slot vocabulary, pick a card type that matches the content's purpose, and reference only semantic tokens — never primitive values directly.

This file is the **single source of truth** for card creation. The catalog has **43 typed patterns** organised in two tracks:

- **§1–§11 — ACKO product patterns.** Domain-grounded cards for insurance flows: policies, alerts, plans, add-ons, network providers, status, commerce, content.
- **§12–§43 — Storybook reference patterns.** Layout-grounded cards mirroring the `Organisms/Cards` Storybook (`CardOrganisms.stories.tsx`, not shipped in the 4.0.3 packages). Each entry names its reference function (e.g. `Card01_CreatorList`) and is itself the spec.

If a brief does not match any of the 43 patterns, **stop and ask** — do not invent a new shape.

---

## Part 0 — Surface System (read before choosing a card)

Cards always sit **on** a surface. The surface controls which card variant is correct. Always choose the surface first, then choose the card.

### Surface types (page / layout)

| Surface name | CSS token | Light / Dark value | When to use |
|---|---|---|---|
| **Primary** | `--surfacePagePrimary` | `#fafafa` (`--solidGrey50`) / `#0f0f10` | Page / fold background — must always be the dominant surface on any page |
| **Secondary** | `--surfacePageSecondary` (`<Surface variant="secondary">`) | `#efeff0` (`--solidGrey150`) / `#0a0a0a` | Visual relief, section differentiation — **never** the first-fold background, **never** consecutive |
| **Static black** | `--surfaceStaticBlack` | `#141414` / `#141414` | Strong differentiation — max 1 per page |
| **Static white** | `--surfaceStaticWhite` | `#ffffff` / `#efeff0` | Designed for dark mode relief; use sparingly in light mode |
| **Brand** | `--surfacePageBrand` | `#491ba5` / `#371678` | Brand moment — max 1 per page |
| **Brand Light** | `--surfaceBrandLight` | `#d9cefd` / `rgba(153,116,249,0.08)` | Soft brand tint — **must always pair with Secondary card** |
| **Inverted** | `--surfacePageInverse` | `#19191a` / `#efeff0` | Dark-on-light (or light-on-dark) differentiation |

> **Page Primary vs Secondary — fill only.** Both are flat. Primary page sections use `--surfacePagePrimary`; Secondary page sections use **`<Surface variant="secondary">`** (recessed `--surfacePageSecondary` fill, no shadow). Do **not** add a shadow to a page band, and do **not** paste raw tokens when `@acko/surface` covers the variant.
>
> **Cards vs page surfaces — do not conflate:**
> - **Page surfaces** → Primary = `--surfacePagePrimary`; Secondary = `--surfacePageSecondary` (**different fills**, both flat).
> - **Cards** (`@acko/card`) → Primary and secondary both use `--cardFillDefault`; **shadow is the only fill-level differentiator** (primary has `--shadowXs`, secondary does not).

> **Not page surfaces:** `--surfaceCard*` tokens (`--surfaceCardDefault`, `--surfaceCardSubtle`, …) are card / component fills — not page Secondary surface and not a substitute for `--surfacePageSecondary`.

### Full-bleed secondary page band (implementation)

Use the two-layer structure from `layout.md`. **Prefer `@acko/surface`** — do not hand-apply page-surface tokens when the component exists.

```tsx
import { Surface } from "@acko/surface";

{/* Full-bleed: Surface has no border-radius of its own */}
<section className="w-full">
  <Surface variant="secondary" padding="none" className="w-full py-64">
    <div className="section-container">{/* content */}</div>
  </Surface>
</section>
```

```tsx
{/* Inset panel (inside section-container) — add the radius yourself */}
<div className="section-container">
  <Surface variant="secondary" padding="lg" className="rounded-[var(--radius5xl)]">
    {/* content */}
  </Surface>
</div>
```

```css
/* Anti-patterns — do not ship */
.secondary-band-wrong {
  background-color: var(--surfacePagePrimary);   /* ❌ primary fill + shadow */
  box-shadow: var(--shadowXs);
}
/* ❌ Also avoid duplicating Surface CSS with inline style when @acko/surface exists */
```

On secondary bands, use **`Card variant="secondary"`** if the section contains cards (flat card on a recessed band — no stacked shadows).

### `@acko/surface` component API and shipped CSS (4.0.3)

```tsx
import { Surface } from "@acko/surface";

interface SurfaceProps {
  variant?: "primary" | "secondary" | "staticBlack" | "staticWhite" | "brand" | "brandLight" | "inverted"; // default "primary"
  padding?: "none" | "sm" | "md" | "lg"; // default "none" — padding on the inner body: 12 / 20 / 24px
  footer?: ReactNode;      // full-width footer row under the body (20px 16px 16px padding)
  onTap?: () => void;      // renders a <button>
  semanticLabel?: string;  // aria-label when onTap is set
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
}
```

**Always use `<Surface>` for secondary (and brand / static / inverted) section shells** — full-bleed bands or inset panels. The root is `display: flex; flex-direction: column; overflow: hidden`, with **no border-radius and no shadow**. Tokens below are what the component applies; reference them for Figma parity, not for copy-paste in app CSS.

| `variant` prop | CSS class | Fill (as shipped) | Border |
|---|---|---|---|
| `"primary"` | `.acko-surface--primary` | `--surfaceBasePrimary` ⚠ | none |
| `"secondary"` | `.acko-surface--secondary` | `--surfaceBaseSecondary` ⚠ | none |
| `"staticBlack"` | `.acko-surface--static-black` | `--surfaceStaticBlack` | `--borderHairline` solid `--cardBorderSecondary` |
| `"staticWhite"` | `.acko-surface--static-white` | `--surfaceStaticWhite` | `--borderHairline` solid `--cardBorderSecondary` |
| `"brand"` | `.acko-surface--brand` | `--surfaceBrand` ⚠ | `--borderHairline` solid `--cardBorderSecondary` |
| `"brandLight"` | `.acko-surface--brand-light` | `--surfaceBrandLight` | `--borderHairline` solid `--cardBorderSecondary` |
| `"inverted"` | `.acko-surface--inverted` | `--surfaceInverted` ⚠ | `--borderHairline` solid `--cardBorderSecondary` |

> ⚠ **Known 4.0.3 bug:** `surface.css` points `primary`, `secondary`, `brand` and `inverted` at tokens that `@acko/tokens` v2 removed. The ACKO boilerplate's `index.css` ships a compat shim so these variants render — use `<Surface variant="…">` as normal and don't hand-roll fallback fills.

### Surface content contract

**`<Surface>` is always full-bleed (edge to edge).** Use `className="w-full"`. Put `section-container` *inside* the Surface for content alignment — never use a padded `<section>` wrapper as the background carrier with an inset Surface inside it.

**Form fields never on a bare Surface.** `TextInput`, `Textarea`, `Dropdown`, `OTP`, `Checkbox`, and `Radio` must live inside a **Card** (or equivalent form shell). This is the only hard restriction.

**Everything else is allowed on a Surface:** Typography, `Button`, `Badge`, `Progress`, `Accordion`, stats, avatars, and other components. Use **Cards** when you want grouped local content with inset padding — not as a mandatory wrapper for every interactive element.

```tsx
{/* ✅ Hero — CTAs and stats on Surface; form in Card only */}
<Surface variant="brandLight" padding="none" className="w-full py-64">
  <div className="section-container grid gap-48 lg:grid-cols-2">
    <div className="flex flex-col gap-24">
      <Badge>Trusted by 1 crore+ Indians</Badge>
      <Typography textStyle="display-xl" as="h1">Headline</Typography>
      <Typography textStyle="body-lg-regular" color="secondary">Supporting copy</Typography>
      <div className="flex gap-12">
        <Button variant="primary">Get your price</Button>
        <Button variant="secondary">Compare plans</Button>
      </div>
      <div className="grid grid-cols-3 gap-24">{/* stat columns */}</div>
    </div>
    <Card variant="primary">
      <form className="flex flex-col gap-20 p-24">
        <TextInput label="Pincode" />
        {/* …other form fields… */}
      </form>
    </Card>
  </div>
</Surface>

{/* ❌ Form fields directly on Surface */}
<Surface variant="brandLight">
  <TextInput label="Pincode" />
  <Dropdown label="Members" />
</Surface>
```

> **Primary page canvas (`--surfacePagePrimary`):** Same form-field rule — never place text inputs on the bare page background. Other components follow the same guidance as on `<Surface>`. Differentiated bands use **`<Surface variant="…">`** full-bleed instead of hand-rolled tokens.

### Surface composition rules (non-negotiable)

1. **Primary surface dominates.** At any point in a page, Primary surface must occupy the highest percentage of total surface area.
2. **Max 3 differentiators per page.** Only use up to 3 non-Primary surfaces total on a single page.
3. **No two differentiating surfaces consecutively.** Never place Brand after Static black, Inverted after Brand, etc. — always return to Primary between differentiators.
4. **Don't change surface without a reason.** Only switch surface when there is a genuine visual or content hierarchy reason. Decorative alternation is an anti-pattern.

---

## Part 1 — Card Base Component

### React API (`@acko/card` + `@acko/css` 4.0.3)

`Card` is the shell (fill, border, radius, shadow) plus optional **parts** you compose in your own order. Plain children still work.

```tsx
import {
  Card, CardMedia, CardBody, CardIllustration, CardBadge, CardTitle, CardNote, CardAction,
} from "@acko/card";
// Every part is also available as Card.Media, Card.Body, Card.Illustration,
// Card.Badge, Card.Title, Card.Note, Card.Action.

interface CardProps {
  variant?: "primary" | "secondary" | "muted" | "ghost" | "accent"; // default: "primary"
  className?: string;
  style?: CSSProperties;   // use only for non-visual layout (e.g. height: "100%")
  onTap?: () => void;      // renders the whole card as a <button> — handles a11y automatically
  semanticLabel?: string;  // aria-label when using onTap
  children?: ReactNode;
}
```

| Part | Props | What it renders |
|---|---|---|
| `Card.Media` | `src`, `alt` (required with `src`; `""` if decorative), `bleed` (default `true`), `badge`, `children`, `className` | 160px-tall media frame, `object-fit: cover`. `bleed` runs it edge to edge at the top (top corners follow the card radius); `bleed={false}` insets it 16px with `--radius3xl` corners. `badge` pins a `Badge` 12px from the top-left. `children` replaces the image (video, illustration). Place it **directly in `Card`, outside `Card.Body`**. |
| `Card.Body` | `children`, `className` | Column flex, **16px padding** (`--spacing16`), **12px gap** (`--spacing12`), `align-items: flex-start`. |
| `Card.Illustration` | `children` (required), `className` | 64×64 illustration box, `aria-hidden`. |
| `Card.Badge` | all `Badge` props | A `Badge` from `@acko/badge`. |
| `Card.Title` | `children`, `as` (`"h2"`–`"h6"`, default `"h3"`), `id`, `className` | Title, always `Typography textStyle="heading-lg"` (20/26 semibold). |
| `Card.Note` | `children`, `tone` (`"info"` \| `"tip"`, default `"info"`), `icon`, `action`, `className` | Side remark strip (`role="note"`): `body-sm-regular` text, 16px tone icon, optional link/action under the text. Info = `--surfaceAccentBlueSubtle` / `--borderAccentBlue`; Tip = `--surfaceAccentPurpleSubtle` / `--borderAccentPurple`; `--radius3xl`. A side remark — never a second paragraph. |
| `Card.Action` | `children` (one `Button`, or an `<a>` styled as a link button), `stretched` (default `false`), `className` | Action row. `stretched` makes the **whole card** clickable through this one action while text stays selectable and only one element is focusable. |

> **No `CardHeader`, `CardContent`, `CardFooter`, or `padding` prop.** Those names do not exist in `@acko/card` — do not import them. Use `Card.Body` for the padded region and `Card.Action` (or a custom footer row) for actions.

> **Parts vs. a custom inner layout.** Use the parts whenever the card is a vertical stack of media → illustration/badge → title → text → note → action; that is what they are built for. Use a **custom inner `<div>`** (owning padding, flex/grid and gap) when the layout is something the parts don't express: horizontal rows (avatar + text + button), split media/text rows (§14/§15/§31), media with an aspect ratio or taller than 160px, cover cards with overlays (§32/§33), or radio/checkbox cards (§10/§11). You can mix them: a custom row can sit inside `Card.Body`. Note `Card.Body` children don't stretch (`align-items: flex-start`) — give full-width rows and `fullWidth` buttons `className="w-full"` (on the row or on `Card.Action`).

> **`onTap` vs `Card.Action`.** `onTap` turns the card root into a `<button>`, so nothing interactive may sit inside it — `Card.Action` and `Card.Note`'s `action` warn in the console if used with `onTap`. If the card needs a visible action **and** a whole-card tap target, use `<Card.Action stretched>` instead of `onTap`.

> **CRITICAL — no inline border or background.** Never pass `border`, `borderRadius`, `backgroundColor`, or `boxShadow` via the `style` prop. The CSS class handles all of these. Overriding them breaks the token chain. Do not put padding on `<Card>` itself — padding belongs on `Card.Body` or your inner wrapper.

### Correct usage pattern

```tsx
import { Card } from "@acko/card";
import { Button } from "@acko/button";
import { Typography } from "@acko/typography";

{/* Parts — vertical stack */}
<Card variant="primary">
  <Card.Media src={heroSrc} alt="" />
  <Card.Body>
    <Card.Badge color="green">Active</Card.Badge>
    <Card.Title>Card title</Card.Title>
    <Typography textStyle="body-md-regular" color="secondary">Supporting text</Typography>
    <Card.Note tone="tip">Renew before 12 Aug to keep your NCB.</Card.Note>
    <Card.Action><Button variant="link">See details</Button></Card.Action>
  </Card.Body>
</Card>

{/* Custom inner layout — when the parts don't fit the shape */}
<Card variant="primary">
  <div className="flex items-center gap-12 p-16">
    <Avatar size={48} initials="RK" />
    <div className="flex min-w-0 flex-1 flex-col">
      <Typography textStyle="body-lg-medium">Rahul Kumar</Typography>
      <Typography textStyle="body-md-regular" color="secondary">@rahulk</Typography>
    </div>
    <Button variant="primary" size="sm">Follow</Button>
  </div>
</Card>
```

### Tappable / selectable cards

When the whole card is interactive and has no inner controls, use `onTap` — the component renders a `<button>` element automatically:

```tsx
<Card
  variant={isSelected ? "primary" : "secondary"}
  onTap={() => setSelected(id)}
  semanticLabel="Select comprehensive plan"
>
  <Card.Body>…</Card.Body>
</Card>
```

For selection state, add a `box-shadow` ring via `className` — **never** override the `border` via `style`:

```css
/* In index.css */
.card-selected {
  box-shadow: 0 0 0 2px var(--cardBorderBrand), var(--shadowXs);
}
```

```tsx
<Card
  variant="primary"
  className={isSelected ? "card-selected" : undefined}
  onTap={…}
>
```

### Variants — Figma name → React prop

| Figma / design system name | `variant` prop | CSS class | Fill | Border | Shadow |
|---|---|---|---|---|---|
| **Primary card** | `"primary"` | `.acko-card--primary` | `--cardFillDefault` | `--borderHairline` solid `--cardBorderDefault` | `--shadowXs` (elevated) |
| **Secondary card** | `"secondary"` | `.acko-card--secondary` | `--cardFillDefault` | `--borderHairline` solid `--cardBorderSecondary` | none (flat) |
| **Muted** | `"muted"` | `.acko-card--muted` | `--cardFillMuted` (grey tint) | `--borderHairline` solid `--cardBorderSecondary` | none |
| **Accent** | `"accent"` | `.acko-card--accent` | `--cardFillAccent` (lavender tint) | `--borderHairline` solid `--cardBorderSecondary` | none |
| **Ghost** | `"ghost"` | `.acko-card--ghost` | `--cardFillGhost` (transparent) | none | none |

> React prop names match Figma directly. `"primary"` = Primary card (elevated). `"secondary"` = Secondary card (flat). Default is `"primary"`. Use `"accent"` for a highlighted / recommended card that should read as tinted rather than elevated.

> **Primary vs secondary rule:** Both use `--cardFillDefault`, and `--cardBorderDefault` / `--cardBorderSecondary` resolve to the same value (`--borderDefaultSoft`) — **elevation is the only differentiator.** Primary adds `--shadowXs`; secondary has no shadow.

### Card-on-surface pairing rules

| Surface | Correct card variant | Reason |
|---|---|---|
| **Primary** (`--surfacePagePrimary`) | `variant="primary"` | Shadow reads cleanly on a flat background |
| **Secondary** (`<Surface variant="secondary">`) | `variant="secondary"` | Flat card on a recessed band — no stacked elevation |
| **Brand Light** (`--surfaceBrandLight`) | `variant="secondary"` | Brand bg is already visually rich — no shadow needed |
| **Brand**, **Inverted**, **Static black**, **Static white** | `variant="primary"` or `variant="secondary"` preferred | Shadow still readable on these surfaces |

> **Sticky nav / header rule:** The top navigation bar must always use `--surfacePagePrimary` as its background. Never use `--surfaceStaticWhite` / `--surfaceStaticWhiteFixed` — they don't follow the page theme and break dark mode.

### Specifications

- Border radius: `--radius5xl` (24px) — set automatically by `.acko-card`
- The `Card` element has `overflow: visible` — clipping must be applied via a wrapping element (or an app class) if needed; `Card.Media` clips its own frame
- Active (pressed) state on tappable cards (and on `Card.Action stretched`) uses `--cardFillHover` background automatically
- Keyboard focus on tappable / stretched cards: `0 0 0 2px` ring in `--dropdownFocusRing` (→ `--borderFocus`) on the card

### Token quick reference (card-specific)

| Token | Value chain (light) | Use |
|---|---|---|
| `--cardFillDefault` | → `--surfaceCardDefault` → `--solidGreyWhite` (`#ffffff`; dark `#141414`) | Fill for **Primary** + **Secondary** card |
| `--cardFillMuted` | → `--surfaceCardMuted` → `rgba(0,0,0,0.05)` | Fill for Muted |
| `--cardFillAccent` | → `--surfaceAccentPurpleSubtle` → `#f2ebff` | Fill for Accent |
| `--cardFillGhost` | → `--surfaceCardGhost` → transparent | Fill for Ghost |
| `--cardFillHover` | → `--surfaceCardHover` | Active/pressed state |
| `--cardFillStaticWhite` / `--cardFillStaticBlack` | → `--surfaceStaticWhiteFixed` / `--surfaceStaticBlackFixed` | Fixed white / black card fills for custom patterns (do not flip with theme) |
| `--cardBorderDefault` | → `--borderDefaultSoft` → `rgba(0,0,0,0.05)` (dark `rgba(255,255,255,0.05)`) | Border for **Primary** |
| `--cardBorderSecondary` | → `--borderDefaultSoft` (same value) | Border for **Secondary**, Muted, Accent |
| `--cardBorderBrand` | → `--borderBrandSubtle` → `--brandPrimary500` (`#7f5dee`) | Selection ring (via `box-shadow`) |
| `--borderHairline` | `0.0625rem` (1px) | Border width |
| `--shadowXs` | Two soft drop shadows (effect style) | Primary **card** elevation only |
| `--surfacePagePrimary` | → `--solidGrey50` | Page **primary** surface fill — flat |
| `--surfacePageSecondary` | → `--solidGrey150` (`#efeff0`) | Page **secondary** bands (`<Surface variant="secondary">`) |
| `--surfacePageBrand` | → `--brandSelectionActive` (`#491ba5`) | Brand surface fill |
| `--surfaceBrandLight` | → `--brandPrimary200` (`#d9cefd`) | Brand Light surface fill |
| `--surfaceStaticBlack` | `#141414` | Static black surface |
| `--surfaceStaticWhite` | `#ffffff` light / `#efeff0` dark | Static white surface |
| `--surfacePageInverse` | `#19191a` light / `#efeff0` dark | Inverted surface |

---

## Part 2 — Card Grammar

1. **Identify the purpose** — match to one of the **43** card types in the catalog
2. **Pick the shell variant** specified for that type
3. **Compose slots** — use only the slots defined for that type
4. **Use real components** — `Card` parts first (`Card.Media`, `Card.Body`, `Card.Title`, `Card.Badge`, `Card.Note`, `Card.Action`), then atoms (Button, Badge, Typography, Avatar, etc.)
5. **Reference semantic tokens only** — never hardcode hex values or primitives

---

## Card layout hierarchy & badge placement (mandatory)

### Reading order — vertical, not split columns

- Do **not** place the **primary title** on the left and **supporting / body** text on the right in the same row. That left/right split is **not** a default card pattern for marketing or product cards.
- Use a **vertical reading order**: optional `eyebrow` → title-reference `status-badge` → `title` → `meta` → `body` → actions in `Card.Action` (or a footer row). Title and subtext **stack**; body copy is not a second column beside the title unless a **documented exception** applies (e.g. a list-event row §31, a horizontal-image card §14/§15 — flagged in their entries).

### Title-reference badges (`status-badge`)

- When a badge **qualifies the headline** (e.g. "Most popular", "New"), it must appear **above the title** in document order.
- It may sit on the **top edge of the card**, including **slight overlap** of the top border — that is a **valid** reference pattern when product chrome calls for it.
- Do **not** place title-reference badges **beside** the title, **below** the title, or in **inconsistent** corners of the card.
- Badges **not** tied to the title (e.g. price chip, ancillary tag) belong in a **separate slot** (`meta`, trailing area, or the card type's defined field) — do not reuse title-reference placement rules for those.

### Actions in card grids

- In a **row of cards** (e.g. plan comparison, feature tiles), **primary actions** must sit at a **consistent vertical position** across cards: use **equal-height** cards (`className="h-full"` on `Card` and `Card.Body`), and push the action to the bottom with `mt-auto` on `Card.Action` or the footer row. Avoid **staggered button heights** when body copy length differs between cards.

---

## Slot Vocabulary

Slots are composable building blocks. A card type's entry lists which slots it uses; do not invent new structural regions outside this list.

### Core slots (used across §1–§43)

| Slot | Description | Typical Component |
|------|-------------|------------------|
| `status-badge` | Above the title — state or title qualifier (Pending, Most popular); may sit on top card edge | `Card.Badge` (= `Badge`) |
| `eyebrow` | Small overline label above the title | `Typography textStyle="label-sm-semibold"` |
| `title` | Primary headline of the card | `Card.Title` (`heading-lg`) in parts-based cards; in custom layouts `Typography textStyle="heading-md"` (or `heading-lg`) as the entry specifies |
| `meta` | Supporting info — id, date, duration, address | `Typography textStyle="body-md-regular" color="secondary"` or `helper-sm-regular` |
| `body` | Secondary descriptive content | `Typography textStyle="body-md-regular"` |
| `media` | Hero image, illustration, or wave placeholder | `Card.Media` (160px frame) or, for aspect-ratio / overlay media, a custom wrapper with `<img>` `object-fit: cover`, or styled gradient block |
| `icon` | Product or entity icon | `@acko/icons` component, sized by a wrapper `<span>` (see `iconography.md`); 64px illustrations use `Card.Illustration` |
| `primary-cta` | Main action for the card | `Button variant="primary"` or `"secondary"`, inside `Card.Action` in parts-based cards |
| `secondary-cta` | Supporting action or text link | `Button variant="ghost"` or `"link"` |
| `footer-link` | Subtle inline link at the bottom | `Button variant="link"` inside `Card.Action` |
| `input` | Inline text entry within the card | `TextInput` |
| `divider` | Horizontal rule between sections | `Separator` |
| `progress` | Progress bar or indicator | `Progress` |
| `inline-notice` | Nested informational strip | `Card.Note` (`tone="info"` / `"tip"`) for side remarks; `Alert` for status messages |

### Extended slots (added for §12–§43)

| Slot | Description | Typical Component |
|------|-------------|------------------|
| `avatar` | Single user/entity avatar | `Avatar` |
| `avatar-stack` | Overlapped avatar row (facepile); negative-margin chain with hairline ring in `--cardFillDefault` | `Avatar` × N inside `flex` row |
| `search-trigger` | Input-shaped tappable pill — `Magnifier` icon + placeholder + `ChevronRight`; `--inputFieldFill` fill, `--inputFieldBorder` stroke, `--radiusFull` | `<button>` (or `<a>`) styled as input |
| `rating` | Star rating row — filled stars in `--surfaceStatusWarning`, empty stars in `--textTertiary` | `<div>` with star glyphs (`★`) |
| `stepper` | Quantity stepper — `Button iconOnly` (`Minus`) + value + `Button iconOnly` (`Plus`) | `Button` × 2 + `Typography textStyle="body-lg-medium"` |
| `feed-stats` | Engagement row — repeated `icon + count` pairs (likes, saves, comments) | `<span>` rows, `--textSecondary` |
| `time-badge` | Small high-contrast time pill — `--surfaceCardInverse` fill, `--textInverse` text, `--radiusSm`, `label-xs-medium` | `<span>` |
| `stat-grid` | 3-column icon + number cells | `<div>` grid |
| `task-list` | Vertical list of `icon + label` rows (Reading task pattern) | `<div>` with `@acko/icons` (e.g. `Mail`) + `Typography` |
| `media-overlay` | Element absolutely positioned over `media` (badge, caption, control) | Composed inside `media-wrap` |
| `play-control` | Play action — circular FAB centred on media (`size="lg" iconOnly`) **or** small chip (`size="sm"` with a leading play icon — see the icon note above §12) | `Button variant="primary"` |
| `host-pill` | Solid role label on solid-fill surfaces — `--textStaticLight` fill, `--textStaticBrand` text, `--radiusFull`, `label-xs-medium` | `<span>` |
| `audience-counter` | `avatar-stack` + circular numeric extra (e.g. `40.2k`) | `Avatar` × N + ringed `<div>` |
| `dismiss` | Close icon button — top-right of card | `Button variant="ghost" size="sm" iconOnly iconLeft={<Close aria-hidden="true" />} aria-label="Close"` |
| `media-caption-bar` | Bottom caption strip on full-bleed media — solid 72% `--surfaceStaticBlackFixed` wash **or** linear gradient `to top` from 88% `--surfaceStaticBlackFixed`; text in `color="static"` | `<div>` absolutely positioned at `bottom: 0` |
| `footer-row` | Hairline-divided footer block (`border-top: var(--borderHairline) solid var(--borderDefaultSubtle)`); content patterns: `view-more` (label + `ChevronRight`), `share` (`Share` + label), `split-meta` (`Family` + count, `Location` + place) | `<div>` (or `Card.Action` for a single link) |

---

## Card Type Catalog

### 1. PolicyCard

**Purpose:** Displays an existing insurance policy (car, bike, health).

**Shell:** `Card variant="primary"` or `variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `icon` | Yes | Product icon — 24px |
| `title` | Yes | Policy name |
| `meta` | Yes | Vehicle reg + coverage expiry |
| `status-badge` | Conditional | Only when expiring/expired/notice |
| `primary-cta` | Conditional | Only for actionable states |
| `secondary-cta` | Optional | |
| `inline-notice` | Optional | Renewal message below actions — `Card.Note` |

**Variants:** `compact` (icon + title + meta + chevron), `standard` (+ expiry badge + actions), `with-notice`

**Token rules:** Expiry text in `--textStatusSuccess` (active) / `--textStatusError` (expired) / `--textStatusWarning` (expiring soon). Chevron: `ChevronRight` from `@acko/icons`, 18px.

---

### 2. PromoCard

**Purpose:** Acquisition, cross-sell, or upsell — drives toward a new product or purchase.

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | Bold value proposition |
| `primary-cta` | Yes | Always present |
| `media` | Conditional | Required for vertical-rich and carousel variants |
| `body` | Optional | Supporting subtitle |
| `eyebrow` | Optional | Offer tag — use `Card.Badge` |

**Variants:**

| Variant | Shell | Layout |
|---------|-------|--------|
| `horizontal-banner` | `Card variant="primary"` + custom inner row (`p-16`) | Text left, image right |
| `vertical-rich` | Custom full-bleed image + gradient overlay | Image fills card, text overlays at bottom |
| `mini` | `Card variant="secondary"` + inner wrapper `p-12` | Eyebrow + title + CTA — compact |
| `carousel-tile` | `Card variant="primary"` + `Card.Media` + `Card.Body` | Image top, label + CTA bottom |

---

### 3. AlertCard

**Purpose:** Status notification — policy update, system message, time-sensitive event.

**Shell:** Custom — no Card wrapper. Full-width banner with left accent border.

| Slot | Required | Notes |
|------|----------|-------|
| `eyebrow` | Yes | Policy/context name |
| `title` | Yes | Status message |
| `body` | Optional | Additional detail |
| `primary-cta` | Optional | Aligned trailing |

**Variants by severity:**

| Variant | Background | Left border | Text color |
|---------|------------|-------------|------------|
| `info` | `--surfaceStatusInfoSubtle` | `--surfaceStatusInfo` | `--textStatusInfo` |
| `warning` | `--surfaceStatusWarningSubtle` | `--surfaceStatusWarning` | `--textStatusWarning` |
| `error` | `--surfaceStatusErrorSubtle` | `--surfaceStatusError` | `--textStatusError` |
| `success` | `--surfaceStatusSuccessSubtle` | `--surfaceStatusSuccess` | `--textStatusSuccess` |
| `neutral` | `--surfaceAccentGreySubtle` | `--borderAccentGrey` | `--textPrimary` |

Left accent border: `4px solid {color}`, full card height. Border radius: `--radius2xl`.

---

### 4. DecisionCard

**Purpose:** Requires explicit user choice before proceeding. High urgency. Blocks flow.

**Shell:** `Card variant="primary"` + `Card.Body`, with colored top border via `className`.

| Slot | Required | Notes |
|------|----------|-------|
| `status-badge` | Yes | "Pending", "On hold", "Action required" |
| `title` | Yes | Clear directive — `Card.Title` (`heading-lg`) |
| `body` | Yes | Context explaining why action is needed |
| `primary-cta` | Yes | `<Card.Action className="w-full"><Button variant="primary" fullWidth>…</Button></Card.Action>` |
| `icon` | Optional | |
| `footer-link` | Optional | "Learn more" |

**Variants:** `pending` (warning border), `on-hold` (error border), `action-required` (error border)

---

### 5. ServiceTile

**Purpose:** Quick-access shortcut to a feature or service. Tappable square.

**Shell:** `Card variant="secondary"` + inner wrapper `p-12` — fixed square aspect ratio.

| Slot | Required | Notes |
|------|----------|-------|
| `icon` | Yes | 24px, `--textPrimary` |
| `title` | Yes | `label-md-medium` — 2 lines max |

Size: 80×80px to 96×96px. No explicit CTA — entire tile is interactive.

---

### 6. NetworkCard

**Purpose:** Provider in a network — hospital, garage, lab. Used in listing contexts.

**Shell:** `Card variant="primary"` or `Card variant="secondary"` + custom inner row (`p-16`)

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | Provider name |
| `meta` | Yes | Rating + distance or address |
| `status-badge` | Optional | Network type ("Cashless") |
| `media` | Optional | Provider thumbnail, 64×64px, `--radiusLg` |
| `footer-link` | Optional | "View details" |

Selected state: `border-color: --cardBorderBrand` + `box-shadow: 0 0 0 1px var(--cardBorderBrand)`

---

### 7. StatusCard

**Purpose:** Shows status of a claim, transaction, booking, or background process.

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `status-badge` | Yes | Current status |
| `title` | Yes | What is being tracked |
| `meta` | Yes | Reference ID, date, timestamp |
| `body` | Optional | Secondary detail |
| `primary-cta` | Optional | "View details" |
| `progress` | Optional | For in-progress states |

**Badge color by state** (`Card.Badge` / `Badge` `color` prop — the component owns the tokens):

| State | `color` |
|-------|---------|
| Completed / Paid | `"green"` |
| Scheduled | `"purple"` |
| Pending / Processing | `"orange"` |
| Failed / Rejected | `"red"` |

---

### 8. CommerceCard

**Purpose:** Pricing, discounts, coupon entry, and reward display.

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | Offer headline or pricing label |
| `primary-cta` | Yes | Apply, Save, Explore |
| `icon` | Conditional | Coupon/offer icon — 24px |
| `input` | Conditional | `TextInput` for coupon code entry |
| `body` | Optional | Savings amount, terms |
| `secondary-cta` | Optional | Remove (for applied state) |

**Variants:** `coupon-input`, `coupon-applied`, `pricing-summary`, `reward`, `offer-banner`

---

### 9. ContentCard

**Purpose:** Editorial content — articles, how-to guides, explanations.

**Shell:** `Card variant="primary"` + `Card.Media` + `Card.Body` for image-top; `Card variant="secondary"` + `Card.Body` for inline banner.

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | Article title |
| `media` | Conditional | Hero image — `Card.Media` (full bleed, 160px tall); use a custom wrapper only if a 16:9 / 3:2 ratio is required |
| `eyebrow` | Optional | Category label — `label-sm-semibold color="brand"` (4.0.3 `brand` colour bug — see `typography.md`) |
| `meta` | Optional | Author, date, read time — `helper-sm-regular` |
| `body` | Optional | Excerpt — 3 lines max |
| `primary-cta` | Optional | "Read more" — `Card.Action` with `Button variant="secondary" size="sm"` (or `variant="link"`) |

**Variants:** `image-top`, `thumbnail-right`, `info-banner`

---

### 10. PlanRadioCard (selectable plan option)

**Purpose:** One **plan option** inside a **radio group** (e.g. bike insurance Comprehensive vs Third-party). User selects **exactly one** plan; the **card shell** shows selection via **border** (not a full-card tint). Used in purchase flows where the card is the **entire hit target** but may include **secondary links** (see exceptions below).

**This is a documented variation** of the card shell: `Card` can't be the interactive element here (see "Why not a plain Card" below), so the real **`Card` component from `@acko/card`** is used as an inner **visual shell only** (`variant="primary"`, no `onTap`), nested inside a plain `<label>` that owns native radio-group behavior via **ACKO radio** class primitives from `@acko/css/radio.css` (`acko-radio-item`, `acko-radio-card-item`, `acko-radio-item-selected`, `acko-radio-native`, `acko-radio-circle` + `acko-radio-dot`, `acko-radio-text`) plus **app-level CSS** for grid layout, borders, and the selected state Card doesn't natively support yet.

**Structure:** `<label>` (native radio semantics, full-width, unstyled) → `<Card variant="primary" className="plan-radio-card acko-radio-card-item ...">` (visual shell; the `<input type="radio">` is Card's **first child** so `:focus-within` still fires on Card's own root, and stays an **immediate sibling** of `.acko-radio-circle` so the DS's `.acko-radio-native:focus-visible + .acko-radio-circle` selector keeps working) → an inner `<div className="plan-radio-card--plan-grid ...">` carrying the grid layout (radio circle, badge, title, main all live here now, not on Card's root). The circle's size comes from `--acko-radio-circle` / `--acko-radio-dot`, which the radio size class (`acko-radio-sm` / `acko-radio-md` / `acko-radio-lg`) sets — put one on an ancestor (e.g. the group wrapper). Add `acko-radio-item-selected` to the item when checked so the circle draws its selected ring and dot.

**Why `variant="primary"`, not `"secondary"`:** this card sits on the flat `Primary` page surface (same surface as any other card on the same screen) — per the Card-on-surface pairing rule (Part 1), Primary surface pairs with `variant="primary"` so the shadow reads correctly against a flat background. `"secondary"` (no shadow) is for cards sitting on a recessed `Secondary` band, which doesn't apply here. The "no extra box-shadow for selection" rule below is about not adding a *different* shadow when selected — not about suppressing the card's baseline elevation entirely.

**Why not a plain `Card`:** `Card`'s only clickable mode (`onTap`) renders a `<button>`; a `<button>` can't provide native `<input type="radio">` keyboard/group semantics (arrow-key navigation between options, real `checked` state). So `Card` is used unclickable (no `onTap`) purely for its visual shell, and the `<label>`+`<input>` around it does the actual interaction.

**Card doesn't support a "selected" state yet:** `Card`'s `variant` enum (primary/secondary/muted/ghost/accent) has no notion of "this one is currently chosen" — the 1px→2px selected border below is still hand-rolled app CSS on top of Card's own classes, same as before this restructure. `Card`'s own radius (`--radius5xl`) also differs from this card's spec (`--radius4xl`) and gets overridden. **TODO(card-selected-state):** once `@acko/card` ships a real selected/active variant or prop, drop the app-level border overrides and drive selection through that instead — the grid layout and radio-input plumbing described above stay either way.

**Reference implementation:** D2C bike journey — `PlanRadioCard` in `app/bike-journey/plans/page.tsx`; styles in `app/globals.css` under `.plan-radio-card*`, `.addon-select-card*` (sibling pattern) — see the `TODO(card-selected-state)` comments there.

#### Shell & border (mandatory)

| State | Border | Token / value |
|-------|--------|----------------|
| Default / unselected | **1px** solid | `var(--cardBorderDefault)` — **matches** `Card variant="primary"` (e.g. bike details / IDV strips on same screen). |
| Selected | **1px** solid | `var(--cardBorderBrand)` — color-only change, same width as unselected (no layout shift on toggle) |
| Hover (unselected) | **1px** | Border `var(--brandPrimary200)` |
| Hover (selected) | **1px** | Border `var(--brandSelectionHover)` |

- **Padding:** `var(--spacing20)`; **radius:** `var(--radius4xl)`; **background:** `var(--cardFillDefault)` (aligns with `Card variant="primary"` shell — same fill as `"secondary"`, `"primary"` additionally adds `--shadowXs`, correct for this card's Primary-surface placement).
- **Transition:** `border-color`, `border-width`, `background-color` (~150ms).
- **Focus:** `@acko/css` 4.0.3 draws no box or focus-within shadow on `.acko-radio-card-item`, so don't add one to the card. Keyboard focus shows on the **radio circle** via **`.acko-radio-native:focus-visible + .acko-radio-circle`** (DS, 2px `--radioBorderFocus` ring).

#### Layout — CSS Grid (not default ACKO flex row)

Use **`plan-radio-card--plan-grid`**: `grid-template-columns: auto 1fr`; **`align-items: center`** on the title row so the **radio** and **plan title** align vertically.

| `plan-radio-card--has-badge` | Grid areas |
|------------------------------|------------|
| **No** | `radio | title` then `main | main` (full width) |
| **Yes** | `badge | badge` (full width), then `radio | title`, then `main | main` |

- **Badge row** must span **both** columns (`badge badge`), **`justify-self: start`**, so the **"Most popular"** pill aligns with the **radio column** — do **not** place the badge only in column 2.
- **Main** (`acko-radio-text.plan-radio-card-main`): set **`gap: 0`** on the text-stack override so spacing is controlled only by inner stacks.

#### Slots (composition)

| Slot | Required | Notes |
|------|----------|-------|
| `status-badge` | Conditional | **"Most popular"** — `Badge variant="solid" color="purple" size="md"` (sentence-case copy); optional **shimmer** (wrapper + `::after` gradient animation; badge `z-index` above shimmer; `margin-bottom: var(--spacing2)` under pill). Respect **`prefers-reduced-motion`**. |
| `title` | Yes | Plan name — `Typography textStyle="heading-lg"` (20/26 semibold), primary. |
| `body` (pointers) | Yes | **Single `<ul>`** — **tenure** lines first, then **coverage** lines; same visual system for all rows: `@acko/icons` **`Tick`** in an 18px wrapper, `var(--textStatusSuccess)`, `Typography textStyle="body-md-medium"` primary; list **`gap: var(--spacing12)`**; row **`gap: var(--spacing8)`** icon-to-text. |
| `footer-link` | Optional | **"More details"** — `Button variant="link" size="sm"`; **`stopPropagation`** on click so the label does not toggle radio. |
| `divider` | Yes | `Separator` between body and price — tuned **`marginTop`** (e.g. `var(--spacing12)`) above separator block. |
| `meta` (price) | Yes | **Row:** `flex flex-nowrap justify-start items-center gap-2`. **Main price:** `Typography textStyle="heading-lg"`. **Strikethrough (optional):** `Typography textStyle="body-lg-regular" color="secondary"` with `line-through` (not heavier unless product specifies). |

**Main block top spacing:** `padding-top: var(--spacing12)` on `.plan-radio-card-main` for space below the title row.

#### Props (data model)

| Prop | Purpose |
|------|---------|
| `groupName` | Radio `name` (from parent `useId()`). |
| `value` / current `plan` | Option id vs selection. |
| `setPlan` | Updates selection. |
| `showHighlightBadge?` | Renders badge row + `plan-radio-card--has-badge`. |
| `title` | Plan name. |
| `tenurePointers` | `string[]` — short tenure lines (same checklist style as features). |
| `features` | `string[]` — coverage bullets. |
| `price` | Formatted amount. |
| `strikethrough?` | Optional old price. |

#### Exceptions to global card rules

- **Nested control:** Rule "no interactive inside fully interactive card" is **relaxed** here for **"More details"**: use **`type="button"`** + **`stopPropagation`** — required for product UX; document in QA.
- **Selection chrome:** Rule 12 in `Rules for LLM Card Generation` references a **box-shadow ring** — for **PlanRadioCard**, selection is a **border** change (see Shell & border) in **primary color**, **not** an extra `box-shadow` on the card.

---

### 11. AddOnCheckboxCard (selectable add-on / upsell line item)

**Purpose:** One **optional insurance add-on** (e.g. Zero Dep, PA cover) in a **multi-select** list. User can toggle **many** add-ons on or off. The **entire card** is the hit target; selection is shown with a **2px primary border** (same mental model as plan cards). Used in purchase flows after plan selection.

**This is a documented variation** of the card shell: the real **`Card` component from `@acko/card`** is used as an inner **visual shell only** (`variant="primary"`, no `onTap`), nested inside a plain (non-`Card`, non-button) `<div>` that owns the "whole card is clickable" tap target. Card carries **`addon-select-card`** + **`addon-select-card--strip`** as `className`; the outer plain div carries **`addon-select-card-tap`**. All visual overrides live in **app-level CSS** in `globals.css` (strip + body + price row).

**Structure:** `<div className="addon-select-card-tap" onClick={...}>` (plain div, owns the tap-to-toggle handler) → `<Card variant="primary" className="addon-select-card addon-select-card--strip ...">` (visual shell — border/fill/radius, overridden below) → `.addon-strip` (top strip: badge, checkbox, title) + `.addon-strip-body` (pointers + price), same as before.

**Why `variant="primary"`, not `"secondary"`:** same Card-on-surface pairing reasoning as PlanRadioCard above — this card sits on the flat `Primary` page surface, so it should carry the same shadow-elevation treatment as every other card on that surface (e.g. the bike details / IDV summary cards on the Plans screen).

**Why the outer div can't be `Card` itself:** the card nests an independently-clickable `<Checkbox>` — tapping it toggles selection without also tapping the card, via `stopPropagation`. `Card`'s only clickable mode (`onTap`) renders the whole thing as a `<button>`, and HTML doesn't allow one interactive control (`Checkbox`) nested inside another (`button`) — that's a hard spec violation, not a style choice, so `Card` is used unclickable here and a plain `<div>` outside it owns the click.

**Card doesn't support a "selected" state yet:** `Card`'s `variant` enum has no "selected" concept (the 2px brand border below is still hand-rolled app CSS on top of Card's own classes). `Card`'s default fill (`--cardFillDefault` → `--surfaceCardDefault`, white in light mode) already matches this card's spec, so no fill override is needed. `Card`'s own radius (`--radius5xl`) also differs from this card's spec (`--radius4xl`) and gets overridden. **TODO(card-selected-state):** once `@acko/card` ships a real selected/active variant or prop and a clickable-`<div>` mode, drop these overrides and the outer wrapper div, and drive selection through the component directly.

**Reference implementation:** D2C bike journey — `AddOnCheckboxCard` in `app/bike-journey/plan-details/page.tsx`; styles under `.addon-select-card*`, `.addon-strip*`, `.addon-pointer-list`, `.addon-strip-price-row` in `app/globals.css`.

#### Shell & border (mandatory)

| State | Border | Notes |
|-------|--------|--------|
| Default / unselected | **2px** solid | `var(--cardBorderDefault)` — aligns with selectable **outline** chrome. |
| Selected | **2px** solid | `var(--cardBorderBrand)` |
| Hover (unselected) | **2px** | `var(--brandPrimary200)` |
| Hover (selected) | **2px** | `var(--brandSelectionHover)` |

- **Radius:** `var(--radius4xl)`; **strip layout** uses **`addon-select-card--strip`** → **`padding: 0`**, **`overflow: hidden`**.
- **Background:** outer card uses `Card`'s own `var(--cardFillDefault)`; **top strip** (`.addon-strip`) uses a **demoted-tint** mix: `color-mix(in srgb, var(--surfaceCardSubtle) 22%, var(--cardFillDefault))` with **bottom hairline** `var(--borderDefaultSubtle)`.
- **Transition:** `border-color`, `background-color` (~150ms).

#### Layout — "structure 2" (mandatory for all add-ons)

Use a **single column** inside the strip:

1. **Optional `status-badge` row** — full width, **`justify-start`**. When present, wrap badge in **`max-w-[min(100%,14rem)]`** so long copy wraps cleanly. Typical: **`Badge variant="solid" color="purple" size="md"`** ("Popular in your city"). **Omit** the row when `stripEnd` is absent.
2. **Checkbox + title row** — **`flex`**, **`gap: var(--spacing12)`**; checkbox column **`pt-2`** for optical alignment with the **`heading-md`** title.
3. Inner stack **`gap: var(--spacing8)`** between badge row and checkbox row (when a badge exists).

**Body (below strip):** `.addon-strip-body` — pointer list + dotted separator + price.

| Region | Class / behaviour |
|--------|-------------------|
| Strip container | `.addon-strip` — padding `var(--spacing16) var(--spacing20)` |
| Pointers | **`<ul class="addon-pointer-list">`** — reuse **PlanRadioCard** row pattern: `@acko/icons` **`Tick`** in an 18px wrapper, **`plan-radio-card-pointer-item`** / **`plan-radio-card-pointer-icon`**, **`Typography textStyle="body-md-medium"`** primary; list **`gap: var(--spacing8)`**. |
| Price | **`.addon-strip-price-row`** — **`Typography textStyle="heading-lg"`**; **dotted rule** via **`::before`** + `repeating-linear-gradient` (not browser `dotted`). |

#### Slots (composition)

| Slot | Required | Notes |
|------|----------|-------|
| `status-badge` | Optional | Title-qualifier pill **above** checkbox + title — **not** beside the title. Omit for add-ons without merchandising. |
| `title` | Yes | Add-on name — **`Typography textStyle="heading-md"`** (semibold), **brand** when selected else **primary** (in 4.0.3 `color="brand"` has a rendering bug — see `typography.md`). |
| `body` (pointers) | Yes | **`string[]`** — checklist rows (same iconography as plan card features). |
| `meta` (price) | Yes | Formatted premium — **dotted line** above price row. |

#### Props (data model)

| Prop | Purpose |
|------|---------|
| `title` | Add-on label. |
| `pointers` | Feature lines for the list. |
| `price` | Number — format with journey **`formatRupees`**. |
| `selected` | Controlled checked state. |
| `onToggle` | `(next: boolean) => void` — invoked on card click or checkbox change. |
| `stripEnd?` | Optional **`ReactNode`** — almost always a **`Badge`**; omit when no badge. |

#### Exceptions to global card rules

- **Nested control:** The whole card is **`onClick`** to toggle, via the **outer plain `<div>`** (not `Card` itself — see "Why the outer div can't be `Card` itself" above). **`Checkbox`** is nested — wrap it in **`stopPropagation`** on **`onClick`** so clicking the checkbox does not double-fire; checkbox **`onChange`** still updates state. Same accessibility pattern as **PlanRadioCard** "More details" (exception to "no nested interactive" for product UX).
- **`Card` is the visual shell, not the click target:** do use **`@acko/card`** (`variant="primary"`, no `onTap`) for the box itself, but keep the tap handler on the plain wrapper `<div>` outside it — see the structure above. Still apply the **documented class names** (`addon-select-card`, `addon-select-card--strip`, etc.) as `Card`'s `className` so strip/body/price styles and the selected-state override apply.

---

## §12–§43 — Storybook Reference Catalog

Cards 12–43 mirror the layouts of the `Organisms/Cards` Storybook (`CardOrganisms.stories.tsx`). Each entry's **Reference** field names the source function. That story is **not shipped in the `@acko/*` 4.0.3 packages**, so treat the entry itself as the spec. All cards in this section use only `@acko/card` (shell + parts), `@acko/button`, `@acko/typography`, `@acko/avatar`, `@acko/badge`, and `@acko/icons`. Helper class names (`sb-card-*`) are app-level classes you define in your own stylesheet; their styles use **only semantic tokens** — no primitives, no raw hex.

> **Shell convention.** "`+ Card.Body`" means the content sits in `Card.Body` (16px padding, 12px gap). Horizontal rows (avatar + text + button, media + text) go in a custom `flex` row **inside** `Card.Body` with `className="w-full"`. Media with an aspect ratio, overlays or a seam overlap uses a custom media wrapper before `Card.Body` and `sb-card-clip` (`overflow: hidden; border-radius: inherit`) on `Card`, because `Card` itself has `overflow: visible`.

> **Icon note.** All icons come from `@acko/icons` (see `iconography.md`; size standalone icons with a wrapper `<span>`, never a `className`/`size` prop on the icon). Names used below: `Magnifier` (search), `ChevronRight`, `Bookmark`, `Messages`, `Mail`, `Share`, `Family` (members), `Location`, `Profile`, `Close`, `Minus`, `Plus`, `ArrowRight`. `@acko/icons` has **no** ellipsis ("More"), play or heart glyph — for those slots ask design for the asset, or drop the slot; don't pull in another icon library.

> **Naming offset:** Storybook function `Card01_*` maps to skill entry **§12**, `Card02_*` to **§13**, …, `Card32_*` to **§43**.

### 12. CreatorListCard

**Purpose:** Header row introducing a list of related people — title on the left, overlapping avatar facepile on the right.

**Reference:** `Card01_CreatorList`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | `Typography textStyle="body-lg-medium"` |
| `avatar-stack` | Yes | 4 × `Avatar size={32}`; chained with **negative left margin** and a **2px ring** in `--cardFillDefault` for separation; `z-index` increases per child so the leftmost is behind. |

**Notes:** Title and avatar stack sit in a single `space-between` row. This is one of the documented exceptions where left/right placement is allowed because **neither side is body copy** — both are peer slots.

---

### 13. SearchRowCard

**Purpose:** Tappable search entry point — looks like a search input but routes to the search screen.

**Reference:** `Card02_SearchRow`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `search-trigger` | Yes | Pill-shaped row: leading `Magnifier` icon, placeholder text in `body-lg-regular` `--textSecondary`, trailing `ChevronRight`; fill `--inputFieldFill`, stroke `--inputFieldBorder`, radius `--radiusFull`. |

**Notes:** This is a **navigation control disguised as an input** — the trigger is a `<button>`/`<a>`, not a real `TextInput`. Aria label must describe the destination (e.g. `aria-label="Search creators"`).

---

### 14. HorizontalImageRightCard

**Purpose:** Article / topic preview with text on the left, square media on the right; rating + bookmark live with the text.

**Reference:** `Card03_HorizontalImageRight`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | `heading-md` |
| `rating` | Yes | 5-star row, filled stars `--surfaceStatusWarning`, empty `--textTertiary` |
| `secondary-cta` | Yes | `Button variant="ghost" size="sm" iconOnly iconLeft={<Bookmark aria-hidden="true" />}` — `aria-label` required |
| `media` | Yes | 104×104 square wave; `--radiusSm` |

**Notes:** This is the **first documented exception** to the vertical-stacking rule. Text occupies the left column, media the right; both columns are vertically `stretch`-aligned. Use **only** for "topic + thumbnail" previews, never for marketing or product cards.

---

### 15. HorizontalImageLeftCard

**Purpose:** Same as §14 but image-leading — used when the media is the dominant signifier (cover art, illustration).

**Reference:** `Card04_HorizontalImageLeft`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `media` | Yes | 104×104 square wave; `--radiusSm` |
| `title` | Yes | `heading-md`, vertically centered |

**Notes:** Same exception as §14. Use the `vcenter` modifier (`align-items: center`) when the body is a single line — keeps the title visually balanced against the media.

---

### 16. TicketCard

**Purpose:** Quantity-controlled ticket / pass row (event tickets, child seats, add-on units).

**Reference:** `Card05_Ticket`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | `body-lg-medium` |
| `meta` | Yes | `body-md-regular` `color="secondary"` (e.g. age range, tier) |
| `stepper` | Yes | `Button variant="secondary" size="sm" iconOnly iconLeft={<Minus aria-hidden="true" />}` + count + `Button …` (`Plus`), each with an `aria-label`; minimum is 1 — disable `−` when `n <= 1`. |

**Notes:** Stepper `Button` is **interactive nested in a non-interactive card** — the `Card` itself has no `onClick`. This is the standard composition; no exception needed.

---

### 17. ProfileFollowCard

**Purpose:** Compact person row with a Follow CTA — list item, search result, recommendation row.

**Reference:** `Card06_ProfileFollow`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `avatar` | Yes | `Avatar size={48}` |
| `title` | Yes | Display name — `body-lg-medium` |
| `meta` | Yes | Handle — `body-md-regular` `color="secondary"` |
| `primary-cta` | Yes | `Button variant="primary" size="sm"` ("Follow") |

---

### 18. SocialFeedCard

**Purpose:** Single social-feed post — author header, body, engagement stats.

**Reference:** `Card07_SocialFeed`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `avatar` | Yes | `Avatar size={40}` |
| `title` | Yes | Author name — `body-lg-medium` |
| `meta` | Yes | Timestamp — `helper-sm-regular` `color="secondary"` (e.g. "· 2 weeks ago") |
| `secondary-cta` | Yes | "More" — `Button variant="ghost" size="sm" iconOnly` + `aria-label`; overflow icon per the icon note |
| `body` | Yes | `body-md-regular` `color="secondary"` |
| `feed-stats` | Yes | Likes (icon per the icon note), saves (`Bookmark`), comments (`Messages`); icons 18px, counts in `helper-sm-regular`, color `--textSecondary`; row `gap-8`, separated `space-between`. |

---

### 19. EventRowCard

**Purpose:** Event / scheduled session row — small thumbnail + time-stamped title + actions.

**Reference:** `Card08_EventRow`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `media` | Yes | 72×56 thumbnail wave; `--radiusLg` |
| `time-badge` | Yes | "07:00 PM" — `--surfaceCardInverse` fill, `--textInverse` text |
| `title` | Yes | `body-lg-medium` |
| `meta` | Yes | Date — `body-md-regular` `color="secondary"` |
| `secondary-cta` | Optional | "More" ghost icon button |

---

### 20. StatBarCard

**Purpose:** Compact analytics summary — three icon + number cells in a single row.

**Reference:** `Card09_StatBar`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `stat-grid` | Yes | 3 cells, `grid-template-columns: repeat(3, minmax(0, 1fr))`; each cell stacks icon (28px, `--textSecondary`) above number (`body-lg-medium`); cell `gap-8`, grid `gap-12`. |

**Notes:** Always 3 cells. Avoid 2 (looks empty) or 4+ (cramped) — split into a second card if more metrics are needed.

---

### 21. ReadingHeaderCard

**Purpose:** Reading-task header — overline label + leading-icon title row.

**Reference:** `Card10_ReadingHeader`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `eyebrow` | Yes | "Reading task" — `helper-sm-regular` `color="secondary"` |
| `icon` | Yes | 20px `@acko/icons` (e.g. `Mail`), `--iconPrimary`, top-aligned with `margin-top: 2px` for optical alignment |
| `title` | Yes | `heading-md` |

---

### 22. ReadingIconBodyCard

**Purpose:** Reading-task with a leading icon, title, and a short description.

**Reference:** `Card11_ReadingIconBody`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `icon` | Yes | 22px `@acko/icons`, `--iconPrimary` |
| `title` | Yes | `heading-md` |
| `body` | Yes | `body-md-regular` `color="secondary"`, ≤ 2 lines |

---

### 23. ReadingInlineLongCard

**Purpose:** Reading-task variant with **inline icon + title** in one row, then a long body paragraph below.

**Reference:** `Card12_ReadingInlineLong`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `icon` | Yes | 20px, inline with title |
| `title` | Yes | `heading-md` |
| `body` | Yes | `body-md-regular` `color="secondary"`, 3–6 lines |

---

### 24. ReadingTaskListCard

**Purpose:** Reading-task with a **list of sub-items** and a Continue CTA — onboarding tasks, learning checkpoints.

**Reference:** `Card13_ReadingTaskList`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `eyebrow` | Yes | "Reading task" |
| `title` | Yes | `heading-md` |
| `task-list` | Yes | Vertical list, `gap-12`; each row: 18px `@acko/icons` icon `--iconPrimary` + label `body-lg-medium`; row `gap-12` icon-to-label. |
| `primary-cta` | Yes | `<Card.Action className="w-full">` + `Button variant="secondary" fullWidth` ("Continue") |

---

### 25. ReadingTimedCard

**Purpose:** Reading-task with a leading **time badge** + title + long body — used when the session is timeboxed.

**Reference:** `Card14_ReadingTimed`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `time-badge` | Yes | `align-self: flex-start` |
| `title` | Yes | `heading-md` |
| `body` | Yes | `body-md-regular` `color="secondary"`, 4–6 lines |

---

### 26. ReadingMediaMetaCard

**Purpose:** Reading-task / lesson preview with a hero media block, overlay time badge, body, and trailing rating + bookmark.

**Reference:** `Card15_ReadingMediaMeta`

**Shell:** `Card variant="secondary" padding="none"` + `sb-card-clip` (overflow hidden so media corners follow card radius)

| Slot | Required | Notes |
|------|----------|-------|
| `media` | Yes | 16:9 wave, full bleed, no inner radius |
| `media-overlay` (`time-badge`) | Yes | Absolutely positioned: `top: 12px; left: 12px;` |
| `title` | Yes | `heading-md`; lives in `Card.Body` |
| `body` | Yes | `body-md-regular` `color="secondary"` |
| `meta` | Yes | Duration in `helper-sm-regular` `color="secondary"` |
| `rating` | Yes | 5-star row |
| `secondary-cta` | Yes | `Bookmark` ghost icon button, trailing |

---

### 27. ProfilePostArticleCard

**Purpose:** Article-style post — author header with Follow, then long-form title and body.

**Reference:** `Card16_ProfilePostArticle`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `avatar` | Yes | `Avatar size={48}` |
| `title` (author) | Yes | `body-lg-medium` |
| `meta` | Yes | Handle — `body-md-regular` `color="secondary"` |
| `primary-cta` | Yes | `Button variant="primary" size="sm"` ("Follow") |
| `title` (article) | Yes | `heading-md` |
| `body` | Yes | `body-md-regular` `color="secondary"` |

**Notes:** Card has **two `title` slots** — author name (in the header) and article title (in the body). Document this in code comments.

---

### 28. HeroCenteredCard

**Purpose:** Centred onboarding / empty-state-style card — avatar, headline, body, full-width primary CTA.

**Reference:** `Card17_HeroCentered`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `avatar` | Yes | `Avatar size={64}` |
| `title` | Yes | `heading-md` `align="center"` |
| `body` | Yes | `body-md-regular` `color="secondary"` `align="center"` |
| `primary-cta` | Yes | `<Card.Action className="w-full">` + `Button variant="primary" fullWidth iconRight={<ArrowRight aria-hidden="true" />}` |

---

### 29. InfoViewMoreCard

**Purpose:** Info / lesson summary with a "View more" footer link.

**Reference:** `Card18_InfoViewMore`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | `heading-md` |
| `body` | Yes | `body-md-regular` `color="secondary"`, 2 lines |
| `meta` | Yes | Duration — `helper-sm-regular` `color="secondary"` |
| `footer-row` (`view-more`) | Yes | Hairline divider + label `body-lg-medium` + `ChevronRight` 20px; full-width `space-between`. |

---

### 30. PricingChooseShareCard

**Purpose:** Pricing card — title, price, primary "Choose" CTA, and a "Share" footer.

**Reference:** `Card19_PricingChooseShare`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | `heading-md` |
| `meta` | Yes | Price — `body-md-regular` `color="secondary"` (e.g. `$39 / person`) |
| `primary-cta` | Yes | `Button variant="primary" size="sm"` ("Choose") |
| `footer-row` (`share`) | Yes | Hairline divider + `Share` 18px + label `body-lg-regular`; inline-flex, `gap-8`. |

---

### 31. ListEventRowCard

**Purpose:** Event row for a vertical list — thumbnail, title, body, trailing time, and a footer with members + location.

**Reference:** `Card20_ListEventRow`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `media` | Yes | 80×80 thumbnail wave; `--radiusSm` |
| `title` | Yes | `heading-md` |
| `body` | Yes | `body-md-regular` `color="secondary"`, 2–3 lines |
| `meta` (time) | Yes | `helper-sm-regular` `color="secondary"`, trailing, `white-space: nowrap` |
| `footer-row` (`split-meta`) | Yes | Hairline divider + two items: (`Family` + member count) and (`Location` + place); `space-between`, both `body-lg-regular` primary. |

**Notes:** This is a documented exception — the body region uses a thumbnail-left + text-right split (similar to §14/§15) because it is a **list row**, not a marketing card.

---

### 32. CoverPlayBottomBarCard

**Purpose:** Full-bleed media cover with a **centred play FAB** and a **bottom caption bar** (course / video preview).

**Reference:** `Card21_CoverPlayBottomBar`

**Shell:** `Card variant="secondary" className="sb-card-clip"` — custom media wrapper first, then `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `media` | Yes | 16:10 wave, `min-height: 220px`, no radius |
| `play-control` (FAB) | Yes | `Button variant="primary" size="lg" iconOnly` + `aria-label="Play"` (play icon per the icon note) centred over media; **override**: fill `--surfaceStaticBlackFixed`, text `--textStaticLight` (`sb-card-cover-play-fab`); `pointer-events: auto` (parent overlay is `none`). |
| `media-caption-bar` | Yes | Bottom strip: solid `color-mix(in srgb, var(--surfaceStaticBlackFixed) 72%, transparent)`; padding `16px 20px`; stacks `helper-sm-regular color="static"` (author) above `heading-md color="static"` (title); `gap-4`. |

---

### 33. CoverAvatarGradientFooterCard

**Purpose:** Full-bleed media cover with a **gradient bottom bar** containing avatar, title stack, and a More button.

**Reference:** `Card22_CoverAvatarGradientFooter`

**Shell:** `Card variant="secondary" className="sb-card-clip"` — custom media wrapper first, then `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `media` | Yes | 16:10 wave, `min-height: 220px` |
| `media-caption-bar` (gradient) | Yes | `linear-gradient(to top, color-mix(in srgb, var(--surfaceStaticBlackFixed) 88%, transparent) 0%, transparent 100%)`; padding `16px 20px`. |
| `avatar` | Yes | `Avatar size={48}` |
| `eyebrow` | Yes | Author — `helper-sm-regular` `color="static"` |
| `title` | Yes | `heading-md` `color="static"` |
| `meta` | Yes | Duration — `helper-sm-regular` `--textStaticLight` (mix of `--textStaticLight` 78% transparent) |
| `secondary-cta` | Yes | "More" icon button — `Button variant="ghost-on-dark"` (static light, no color override) |

---

### 34. InsetMediaProfileRowCard

**Purpose:** White card with an **inset rounded media block at the top**, then a profile row + More button.

**Reference:** `Card23_InsetMediaProfileRow`

**Shell:** `Card variant="secondary" className="sb-card-clip"` — custom media wrapper first, then `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `media` | Yes | **Inset** media — `Card.Media bleed={false}` (16px inset, `--radius3xl` corners, 160px tall); use a custom 16:10 wrapper only if the ratio is required |
| `avatar` | Yes | `Avatar size={48}` |
| `title` | Yes | `body-lg-medium` |
| `meta` | Yes | Handle — `body-md-regular` `color="secondary"` |
| `secondary-cta` | Yes | "More" ghost icon button |

---

### 35. ReadingGradientFacepileCard

**Purpose:** Reading-task card on a **purple-to-blue gradient surface** — facepile, eyebrow, title, duration, play chip.

**Reference:** `Card24_ReadingGradientFacepile`

**Shell:** `Card variant="secondary"` + `Card.Body`, `className="sb-card-reading-gradient sb-card-clip"`

- **Background:** `linear-gradient(125deg, var(--surfaceBrandStrong) 0%, var(--surfaceAccentBlue) 100%)`
- **Border:** transparent (gradient does the work)
- **Text:** all text uses `color="static"` or the muted alias `color-mix(in srgb, var(--textStaticLight) 78%, transparent)`

| Slot | Required | Notes |
|------|----------|-------|
| `avatar-stack` | Yes | 4 × `Avatar size={40}`; ring color `color-mix(in srgb, var(--textStaticLight) 35%, transparent)` for visibility on gradient |
| `eyebrow` | Yes | "Reading task" — `label-sm-semibold` muted-static |
| `title` | Yes | `heading-lg` `color="static"` |
| `meta` | Yes | Duration — `helper-sm-regular` muted-static |
| `play-control` (chip) | Yes | `Button variant="primary" size="sm"` ("Play", leading icon per the icon note); chip override: fill `--surfaceStaticBlackFixed`, text `--textStaticLight`. |

---

### 36. HostSolidLocationCard

**Purpose:** Solid-primary host card — host avatar + name + Host pill, title, location.

**Reference:** `Card25_HostSolidLocation`

**Shell:** `Card variant="secondary"` + `Card.Body`, `className="sb-card-host-solid"`

- **Background:** `--surfaceBrandStrong` (solid)
- **Border:** transparent
- **All text:** `color="static"`

| Slot | Required | Notes |
|------|----------|-------|
| `avatar` | Yes | `Avatar size={40}` |
| `title` (host) | Yes | Host name — `body-lg-medium` `color="static"` |
| `host-pill` | Yes | "Host" — fill `--textStaticLight`, text `--textStaticBrand`, radius `--radiusFull`, `label-xs-medium` |
| `title` (event) | Yes | `heading-lg` `color="static"` |
| `footer-row` (`split-meta`) | Yes | `Location` 18px + place name — both static; no top divider on solid surface (gap only). |

---

### 37. HostDenseAudienceCard

**Purpose:** Dense host card — title row with More, audience facepile + count, footer date + play chip.

**Reference:** `Card26_HostDenseAudience`

**Shell:** `Card variant="secondary"` + `Card.Body`, `className="sb-card-host-solid"`

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | `heading-lg` `color="static"`; same row as the "More" icon button (`variant="ghost-on-dark"`). |
| `secondary-cta` | Yes | "More" icon button, `variant="ghost-on-dark"` |
| `audience-counter` | Yes | 4 × `Avatar size={64}` overlapped + 56×56 ringed `<div>` containing `Profile` 18px + count (e.g. "40.2k") in `label-sm-medium`; ring `2px solid --textStaticLight`. |
| `meta` | Yes | "2 hours · October 30, 2023" — `helper-sm-regular`, `color-mix(--textStaticLight 72%, transparent)` |
| `play-control` (chip) | Yes | Same chip override as §35. |

---

### 38. CourseApplyCard

**Purpose:** Course / event signup — time badge, title, duration, full-width Apply.

**Reference:** `Card27_CourseApply`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `time-badge` | Yes | `align-self: flex-start` |
| `title` | Yes | `heading-md` |
| `meta` | Yes | Duration — `body-md-regular` `color="secondary"` |
| `primary-cta` | Yes | `Button variant="primary" fullWidth` ("Apply") |

---

### 39. ProfileSheetFollowCard

**Purpose:** Profile sheet / dialog-style card — top dismiss, centred avatar/name/handle, full-width Follow.

**Reference:** `Card28_ProfileSheetFollow`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `dismiss` | Yes | `Button variant="ghost" size="sm" iconOnly iconLeft={<Close aria-hidden="true" />} aria-label="Close"`; row `justify: flex-end`; ghost color `--textSecondary`. |
| `avatar` | Yes | `Avatar size={64}`, centred |
| `title` | Yes | `heading-md` `align="center"` |
| `meta` | Yes | Handle — `body-md-regular` `color="secondary" align="center"` |
| `primary-cta` | Yes | `Button variant="primary" fullWidth` ("Follow") |

---

### 40. CreatorChipCard

**Purpose:** Minimal horizontal "creator chip" — avatar + name + role label. Often used inline within feeds.

**Reference:** `Card29_CreatorChip`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `avatar` | Yes | `Avatar size={40}` |
| `title` | Yes | Name — `body-lg-medium` |
| `meta` | Yes | Role label — `body-md-regular` `color="brand"` (e.g. "Creator") |

**Notes:** Single-row layout; meta uses `color="brand"` instead of `secondary` because the role is the value proposition (4.0.3 `brand` colour bug — see `typography.md`).

---

### 41. CoursePreviewStackCard

**Purpose:** Course preview — hero media, then left-aligned instructor + course title + duration.

**Reference:** `Card30_CoursePreviewStack`

**Shell:** `Card variant="secondary" className="sb-card-clip"` — custom media wrapper first, then `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `media` | Yes | 16:9 wave, full bleed |
| `eyebrow` | Yes | Instructor — `helper-sm-regular` `color="secondary"` |
| `title` | Yes | `heading-md` |
| `meta` | Yes | Duration — `body-md-regular` `color="secondary"` |

**Notes:** Body region is `Card.Body` (16px padding).

---

### 42. CoursePreviewOverlapCard

**Purpose:** Course preview with an **avatar overlapping the seam** between media and body — centred body content + footer "View contents" link.

**Reference:** `Card31_CoursePreviewOverlap`

**Shell:** `Card variant="secondary" className="sb-card-clip"` — custom media wrapper first, then `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `media` | Yes | 16:9 wave |
| `avatar` | Yes | `Avatar size={64}`; `margin-top: -32px` to overlap; **3px ring** in `--cardFillDefault` to read against media; `border-radius: --radiusFull`. |
| `title` (instructor) | Yes | `body-lg-medium` |
| `meta` | Yes | Course title — `body-md-regular` `color="secondary"` |
| `footer-row` (`view-more`) | Yes | `Button variant="link"` ("View contents"); link override: color `--textSecondary`, no underline; on hover, color `--textPrimary` + underline. Top hairline `--borderDefaultSubtle`. |

---

### 43. CoursePreviewTitleFirstCard

**Purpose:** Centred course preview — title above a square media block, then a "View contents" footer.

**Reference:** `Card32_CoursePreviewTitleFirst`

**Shell:** `Card variant="secondary"` + `Card.Body`

| Slot | Required | Notes |
|------|----------|-------|
| `title` | Yes | `heading-md` `align="center"` |
| `media` | Yes | Square wave, `max-width: 240px`, `aspect-ratio: 1`, `--radiusSm` |
| `footer-row` (`view-more`) | Yes | Same `view-contents` link pattern as §42. |

**Notes:** Body region is centred (`align-items: center`) with `gap-16`.

---

## Shell Selection Guide

> All variants below refer to the **React `variant` prop** — the prop name matches the Figma name directly (`"primary"` / `"secondary"` / `"muted"` / `"accent"` / `"ghost"`).
> `Card` has **no `padding` prop**. Use `Card.Body` (16px) or a custom inner `<div>` wrapper.

| Card Type | Variant on Primary surface | Variant on Secondary surface | Notes |
|-----------|--------------------------|------------------------------|-------|
| §1 PolicyCard | `primary` | `secondary` | — |
| §2 PromoCard | `primary` | `secondary` | Rich variants use gradient overlay — not a card surface |
| §3 AlertCard | Custom (no Card wrapper) | — | Full-width banner with left accent border |
| §4 DecisionCard | `primary` | `secondary` | Coloured top border added via `className` |
| §5 ServiceTile | `primary` | `secondary` | — |
| §6 NetworkCard | `secondary` | `secondary` | Selection ring via `box-shadow: 0 0 0 2px var(--cardBorderBrand)` |
| §7 StatusCard | `primary` | `secondary` | — |
| §8 CommerceCard | `secondary` | `secondary` | — |
| §9 ContentCard | `primary` | `secondary` | — |
| §10 PlanRadioCard | `primary` as visual shell inside a `<label>` (no `onTap` — see §10) | — | Idle border `var(--cardBorderDefault)`; selected `var(--cardBorderBrand)` — see §10 Shell & border |
| §11 AddOnCheckboxCard | `primary` as visual shell inside a clickable `<div>` (no `onTap` — see §11) | — | 2px border idle/selected; strip uses `--surfaceCardSubtle` tint |
| §12–§43 Storybook cards | `primary` on Primary surface | `secondary` on Secondary surface | Follow surface pairing rule from Part 1 |

---

## Token Quick Reference

> Always use these camelCase token names in CSS. The kebab-case `--color-*` entries in `@acko/tokens/theme.css` exist only to generate Tailwind utilities (e.g. `bg-surface-page-secondary`). Removed in tokens v2 — don't use: `--surfaceBase` → `--surfacePagePrimary`, `--surfaceSecondaryBg` → `--surfacePageSecondary`, `--surfaceInverted` → `--surfacePageInverse`, `--cardFillDisable` → `--cardFillMuted`, `--cardFillHighlight` (gone), `--statusXText` → `--textStatusX`, `--statusXBase` → `--surfaceStatusX`, `--borderSubtle` → `--borderDefaultSubtle`, `--textLink` → `--textLinkDefault`, `--fillBrand*` / `--brandPrimary` → `--surfaceBrand*` / `--brandSelectionDefault`.

### Card and surface tokens

| Token | Use |
|-------|-----|
| `--cardFillDefault` | Card fill — Primary + Secondary (`@acko/card` primary and secondary share this token) |
| `--cardFillMuted` | Card fill — Muted |
| `--cardFillAccent` | Card fill — Accent |
| `--cardFillGhost` | Card fill — Ghost (transparent) |
| `--cardFillHover` | Card fill — active/pressed state |
| `--cardBorderDefault` | Border — Primary (`rgba(0,0,0,0.05)` light / `rgba(255,255,255,0.05)` dark) |
| `--cardBorderSecondary` | Border — Secondary, Muted, Accent (same value) |
| `--cardBorderBrand` | Selection ring (via `box-shadow`, not `border`) |
| `--borderHairline` | Border width (1px) |
| `--shadowXs` | Primary **card** elevation |
| `--surfacePagePrimary` | Page **primary** surface — flat |
| `--surfacePageSecondary` | Page **secondary** bands / `<Surface variant="secondary">` — flat |
| `--surfaceCardSubtle` | Demoted tint inside cards (e.g. §11 strip) — **not** a page surface |
| `--surfacePageBrand` | Brand surface fill |
| `--surfaceBrandLight` | Brand Light surface fill |
| `--surfaceStaticBlack` | Static black surface fill |
| `--surfaceStaticWhite` | Static white surface fill |
| `--surfaceStaticBlackFixed` | Fixed black for media washes / overlays (does not flip in dark mode) |
| `--surfacePageInverse` | Inverted surface fill |
| `--surfacePageMuted` | Muted overlay tint |
| `--surfaceBrandStrong` | Solid brand fill on custom cards (§36, §37), gradient stop |
| `--surfaceBrandSubtle` | Brand subtle tint (wave placeholder, icon bg tint) |
| `--surfaceAccentBlue` | Blue gradient stop (§35, wave placeholder) |
| `--inputFieldFill` | Search-trigger fill (§13) |
| `--inputFieldBorder` | Search-trigger stroke (§13) |
| `--textPrimary` | Primary text |
| `--textSecondary` | Secondary / supporting text |
| `--textBrandDefault` | Brand-coloured text (links, active labels) |
| `--textStaticLight` | Fixed white text on dark/gradient/solid surfaces |
| `--textStaticBrand` | Fixed brand text on a fixed white fill (§36 host-pill) |
| `--surfaceCardInverse` / `--textInverse` | `time-badge` fill / text |
| `--surfaceStatusWarning` | Filled stars in `rating` slot |
| `--textTertiary` | Empty stars in `rating` slot |
| `--borderDefaultSubtle` | Hairline dividers (`footer-row`, §11 strip) |

### Spacing in cards (1px-base, per `scales.md`)

`@acko/tokens` ships `--spacing: 0.0625rem` (in `theme.css`), so utility numbers equal pixel values.

| Utility | Pixels | Use |
|---------|--------|-----|
| `gap-4` | 4px | Caption-bar inner stack (§32, §33) |
| `gap-8` | 8px | Icon-to-text, tight rows, stat-cell stacks |
| `gap-12` | 12px | `Card.Body` gap, reading-stack default, footer-row gaps, list rows |
| `gap-16` | 16px | `Card.Body` padding, internal section gaps, `sb-card-split` gap |
| `gap-20` | 20px | §10 radio-card padding |
| `gap-24` | 24px | Roomy custom inner wrapper, gallery grid gap |

**Card padding:** `Card.Body` is fixed at 16px padding / 12px gap. When an entry needs different padding (e.g. 12px for compact tiles), use a custom inner wrapper (`p-12`) instead of `Card.Body`.

### Border radius

| Token | Value | Use |
|-------|-------|-----|
| `--radiusSm` | 4px | `time-badge`, inset media thumbnails (§14, §15, §31, §43) |
| `--radiusLg` | 8px | Provider thumbnails, small thumbs (§19) |
| `--radius2xl` | 12px | AlertCard, inline notices |
| `--radius3xl` | 16px | `Card.Media` inset frame, `Card.Note` |
| `--radius4xl` | 20px | §10 / §11 selectable card spec (overrides Card's radius) |
| `--radius5xl` | 24px | All `@acko/card` containers (set by `.acko-card`) |
| `--radiusFull` | 9999px | Badges, pills, search-trigger, host-pill, audience ring |

### Shadows

| Token | Use |
|-------|-----|
| `--shadowXs` | Elevated card shell (`Card variant="primary"`) |
| `--shadowS` / `--shadowM` | Small raised elements inside or over a card (FAB, floating chip) |
| `--shadowL` / `--shadowXl` | Larger floating layers — not card shells |

> `--shadowCard` / `--shadowSubtle` never existed. `--elevationCard` exists (`--elevationE3`) but `@acko/card` uses `--shadowXs` — match the component.

### Wave / placeholder gradient (Storybook media)

```css
background: linear-gradient(
  125deg,
  var(--surfaceBrandSubtle) 0%,
  var(--surfaceAccentBlue) 45%,
  var(--surfaceBrandStrong) 100%
);
```

Used for `media` slots in §12, §14, §15, §19, §26, §31–§34, §41–§43. Replace with real imagery in production; gradient is a placeholder.

---

## Rules for LLM Card Generation

1. **Match type first** — identify which of the **43** types the card is. Closest type wins; extend minimally. If nothing fits, **stop and ask** — do not invent a new shape.
2. **Only use defined slots** — do not invent new structural regions. The Slot Vocabulary is the contract.
3. **One primary CTA per card** — never two primary buttons in the same card.
4. **Tokens only** — never write a raw hex, rem, or px value for color or spacing. Spacing utilities are 1px-base (`gap-12` = 12px); see `scales.md`.
5. **Typography via component** — always use `Typography` with a `textStyle` (or `Card.Title` / `Card.Note`, which render `Typography` for you); never raw `<h*>`, `<p>`, or inline `font-*` styles. `Typography` has no `variant` or `weight` prop — weight is part of the `textStyle` name.
6. **Badge for status** — any state label uses `Badge` / `Card.Badge`, not custom text.
7. **No decorative borders inside default cards** — use `Separator` only for genuine content divisions.
8. **Card width is always contextual** — cards never define their own `width`. Parent layout controls it.
9. **Dark theme is inherited** — do not write per-card dark-theme overrides. Semantic tokens handle it.
10. **Media must have a fallback** — if a `media` slot image fails, the card must still be usable.
11. **No CTA inside fully-interactive cards** — when the entire card is a tap target (`onTap`), do not nest `Button`, `Card.Action` or any interactive component inside it. If the card needs one visible action plus a whole-card target, use `<Card.Action stretched>` instead of `onTap`. **Documented exceptions:** §10 PlanRadioCard ("More details" link with `stopPropagation`), §11 AddOnCheckboxCard (nested `Checkbox` with `stopPropagation`).
12. **Selection state lives on the card shell** — variant change + visible border treatment (`box-shadow: 0 0 0 2px var(--cardBorderBrand)`, **or** §10's 1→2px border, **or** §11's 2px primary border). Never use a `Badge` or internal element to indicate selection.
13. **Title and body stack vertically by default** — never default to title-left / subtext-right in one row. **Documented split-row exceptions:** §12 (title + facepile), §14 / §15 (text + thumbnail), §31 (list-event row), §37 (title + More button).
14. **Title-reference badges stay above the title** (top-edge overlap allowed). Align primary CTAs across cards in a grid to the same vertical position.
15. **Cover and gradient surfaces use static text** — on `media-caption-bar`, `sb-card-host-solid`, and `sb-card-reading-gradient` surfaces, all text uses `Typography color="static"` (or the muted-static `color-mix` alias). Never rely on `--textPrimary` over dark/gradient fills.
16. **Reference the Storybook function** — when implementing §12–§43, name the source function (e.g. `Card01_CreatorList`) in the component file's top comment so the canonical layout is traceable.
